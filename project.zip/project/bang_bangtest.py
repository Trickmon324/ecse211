from utils.brick import Motor, EV3UltrasonicSensor, wait_ready_sensors, reset_brick
from collections import deque
import time


# Devices
ultra = EV3UltrasonicSensor(1)

left_motor = Motor("A")
right_motor = Motor("D")

wait_ready_sensors()

BAND_CENTER = 20
BAND_WIDTH  = 3
TURN_DPS = 220
TURN_TIME = .25
BASE_POWER = 35
CORRECTION = 20

distance_list = deque(maxlen=3)

def get_distance():
    distance = ultra.get_cm()
    
    if distance is None:
        distance = 255
        
    distance_list.append(distance)
    values = sorted(distance_list)
    
    return values[len(values) // 2]

try:
    while True:
        distance = get_distance()
        print("Distance:", distance)
        
        if distance < BAND_CENTER + BAND_WIDTH:
#             left_motor.set_power(BASE_POWER + CORRECTION)
            
            # starts with a stop
            left_motor.set_dps(0)
            right_motor.set_dps(0)
            time.sleep(.1)
            
            # turns right
            
            left_motor.set_dps(TURN_DPS)
            right_motor.set_dps(-TURN_DPS)
            time.sleep(TURN_TIME)
            
            # stop briefly after a turn
            
            left_motor.set_dps(0)
            right_motor.set_dps(0)
            time.sleep(0.1)
            
        elif distance > BAND_CENTER - BAND_WIDTH:
#             left_motor.set_power(BASE_POWER - CORRECTION)
#             right_motor.set_power(BASE_POWER)
            
            #stop first
            left_motor.set_dps(0)
            right_motor.set_dps(0)
            time.sleep(.1)
            
            #turn left
            left_motor.set_dps(TURN_DPS*0.8)#turn not pivot!!!!!!
            right_motor.set_dps(+TURN_DPS)
            time.sleep(TURN_TIME)
            
            left_motor.set_dps(0)
            right_motor.set_dps(0)
            time.sleep(.1)
            
        else:
            left_motor.set_power(BASE_POWER)
            right_motor.set_power(BASE_POWER)
        time.sleep(.05)
        
except KeyboardInterrupt:
    print("Stopping robot")
finally:
    reset_brick()