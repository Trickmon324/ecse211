#!/usr/bin/env python3

"""
This test is used to collect data from the color sensor.
It must be run on the robot.
"""

# Add your imports here, if any
from utils.brick import EV3ColorSensor, wait_ready_sensors, TouchSensor, reset_brick
import time
from config import *

COLOR_SENSOR_DATA_FILE = "/home/pi/ecse211/W26/final-project-main/final-project-main/final project/final project/data_analysis/color_sensor_1.csv"
COLOR_SENSOR = EV3ColorSensor(3) #can be changed to any port
TOUCH_SENSOR = TouchSensor(1)

# wait_ready_sensors(True) # Input True to see what the robot is trying to initialize! False to be silent.


def collect_color_sensor_data():
    "Collect color sensor data."
    
    try:
        #open csv file to write data in
        with open(COLOR_SENSOR_DATA_FILE, "w") as f: 

            #loop to continuously check for button press
            while True:

                #if statement to check if button is pressed
                if TOUCH_SENSOR.is_pressed():
                    rgb_stats = COLOR_SENSOR.get_rgb() # get rgb data

                    # ensure the color sensor returned valid RGB values
                    if rgb_stats: 
                        r, g, b = rgb_stats
                        f.write(f"{r},{g},{b}\n") # data to csv file

                        print(f"RGB values: R: {r}, G: {g}, B: {b}")

                    #Wait for button release to avoid multiple entries
                    while TOUCH_SENSOR.is_pressed():
                        time.sleep(0.05) 

                time.sleep(0.05) #small delay to prevent high CPU usage



    except FileNotFoundError:   
        print(f"File directory not found") #shouldn't be an issue but just in case
    
    except KeyboardInterrupt: # Capture Ctrl-C to stop the program
        print("Program stopped by user.")
    
    except BaseException as e: #Catch all other exceptions
        print(f"An unexpected error occurred: {e}")

    finally:
        print("Done") #to know when testing is done
        reset_brick() #reset the brick hardware
        exit()


    





    


if __name__ == "__main__":
    collect_color_sensor_data()
