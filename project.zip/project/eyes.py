import config
from collections import deque
import math
import time

class Eyes:

    def __init__ (self, color_sensor, us_sensor, gyro_sensor, color_motor):

        #create list for rgb data
        self.black_threshold = config.BLACK_LINE_THRESHOLD
        self.line_target = config.LINE_TARGET # change based on testing
        #safe distance for US sensor
        self.color_sensor = color_sensor
        self.set_mode('red')
        self.us_sensor = us_sensor
        self.gyro_sensor = gyro_sensor
        self.color_motor = color_motor
        self._gyro_offset = 0

    def _is_color (self, ref_color):
        """Checks if the color sensor detects a specific color"""
        point = self.get_norm_rgb()
        if point is None:
            return False
        
        #calculate distance from ref_color, if within threshold then it is that color
        dist = math.dist(ref_color, point)

        return dist < config.DIST_THRESH

    def hard_reset_gyro(self):
        """Forces the gyro sensor to reset and zero out"""
        self.gyro_sensor.set_mode('abs')
        self.gyro_sensor.wait_ready()
        self.gyro_sensor.set_mode('both')
        self.gyro_sensor.wait_ready()
        self.gyro_sensor.set_mode('abs')
        self.gyro_sensor.wait_ready()
        time.sleep(0.25)
        
        self._gyro_offset = self.gyro_sensor.get_value() or 0
        
    def soft_reset_gyro(self, expected_heading = 0):
        raw = self.gyro_sensor.get_value() or 0
        self._gyro_offset = raw - expected_heading
        print(f"Gyro soft reset. Raw: {raw}, Expected: {expected_heading}, Offset: {self._gyro_offset}")
        
    def get_corrected_heading(self):
        raw = self.gyro_sensor.get_value() or 0
        return raw - getattr(self, '_gyro_offset', 0)

    def set_mode (self, mode_name):
        """Sets mode for the color sensor"""
        self.color_sensor.set_mode(mode_name)
        print(f"Color sensor set to {mode_name}")
        self.color_sensor.wait_ready()     

    def get_light_intensity (self):
        """Returns the reflected intensity"""
        return self.color_sensor.get_value()

    def get_norm_rgb (self):
        """Gets RGB data and normalize it"""
        rgb_stats = self.color_sensor.get_rgb()
        if not rgb_stats:
            return None
        r,g,b = rgb_stats
        denominator = r + g + b + config.EPSILON

        return [r/denominator, g/denominator, b/denominator]

    def get_red_or_green(self):
        """Returns RED or GREEN (or other) based on RGB data"""
        point = self.get_norm_rgb()
        if point is None:
            return None
        
        #calculate distance from red and green, return the closer color if within threshold, otherwise return None
        red_dist = math.dist(config.RED, point)
        green_dist = math.dist(config.GREEN, point)

        if red_dist < green_dist and red_dist < config.DIST_THRESH:
            print("Red bed")
            return "RED"
        elif green_dist < red_dist and green_dist < config.DIST_THRESH:
            print("Green bed")
            return "GREEN"
        else:
            return None

    def is_intersection (self):
        """Retruns True if the light intensity drops below the Black threshold"""
        #maybe add a streak filter maybe (check for 2 consecutive "black" readings)

        #checks for black readings, which would indicate an intersection (node)
        current_light = self.get_light_intensity()
        return current_light < self.black_threshold
    
    def is_room(self):
        """Returns True if RGB data matches yellow"""
        return self._is_color(config.YELLOW)

    def is_door (self):
        """Returns True if RGB data matches Orange"""
        return self._is_color(config.ORANGE)

    def turn_color_motor(self, angle):
        """Turns the color motor to a specific heading"""
        
        self.color_motor.set_limits(power = 30)
        self.color_motor.set_position(angle)
        

    #logic for sensing medicine cubes if needed

    #Things to improve:
    #1. Delete useless comments
    #2. Remove deque
    #3. Magic numbers should be constants and initialize all config constants