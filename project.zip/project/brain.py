
import config
import time

class Brain:

    def __init__ (self, driver, eyes, hands, delivery_count = 2):

       self.driver = driver
       self.eyes = eyes
       self.hands = hands
       self.route = config.MISSION_ROUTE.copy()
       self.current_node = "NODE_0"
       self.return_path = ["NODE_0"]
       self.delivery_count = delivery_count
       self.map = config.HOSPITAL_GRAPH

    def get_path_info(self, from_node, to_node):
        """Returns (distance, direction) between two nodes from the hospital graph."""
        edge = self.map[from_node][to_node]
        return edge[0], edge[1]

    def set_up (self):
        """Pick up medecine and position the robot to node 0"""
        self.eyes.color_motor.reset_encoder()
        self.eyes.hard_reset_gyro()
        time.sleep(1)
        self.eyes.turn_color_motor(75)
        time.sleep(0.5)
        self.driver.dist_gyro(26, 0)
        time.sleep(1.5)
        self.hands.pick_up()
        time.sleep(1)
        self.driver.drive_distance(7, 40)
        time.sleep(1)
        self.driver.turn(25)
        time.sleep(1)
        self.driver.drive_distance(-8, 50)
        time.sleep(1)
        self.hands.pick_up()
        time.sleep(1)
        self.driver.drive_distance(8, 50)
        time.sleep(1)
        self.driver.turn(-2)
        time.sleep(1)
        self.driver.drive_distance(12.7, 50)
        time.sleep(1)
        self.driver.turn(-88.2)
        time.sleep(1)
        self.eyes.turn_color_motor(0)
        time.sleep(1)
        self.driver.stop()
        pass

    def execute_next_step (self):
        """Follows the route and checks distance and direction"""
        if not self.route:
            return False
        
        #gets the next node to go to from the route
        next_node = self.route.pop(0)
        
        try:
            #gets the distance and direction to the next node from the map
            distance, direction = self.get_path_info(self.current_node, next_node)

            print(f"Moving from {self.current_node} to {next_node} with distance {distance} and direction {direction}")
        except KeyError:
            print(f"Error: Could not find path from {self.current_node} to {next_node}")
            return False

        #turns and follows the line to the next node
        if abs(direction - self.driver.gyro_sensor.get_abs_measure() + 180) % 360 > 30:
            self.driver.turn_pivot(direction)
            time.sleep(0.1)
        
        if next_node == "NODE_4":
            self.eyes.turn_color_motor(-90)
            time.sleep(0.5)
            self.driver.dist_gyro(4.7, direction)

        elif distance <= 15:
            self.eyes.turn_color_motor(0)
            time.sleep(0.1)
            self.driver.dist_gyro(17.5, direction)
            #self.driver.line_dist(15)
            time.sleep(0.5)
            self.eyes.hard_reset_gyro()
            time.sleep(1)

        elif next_node == "NODE_1":
            self.eyes.turn_color_motor(0)
            time.sleep(0.1)
            self.driver.follow_until_node(distance)
            time.sleep(0.5)
        
        else:
            self.eyes.turn_color_motor(0)
            time.sleep(0.1)
            #self.eyes.hard_reset_gyro()
            self.driver.follow_until_node(distance)
            time.sleep(0.5)
            self.eyes.hard_reset_gyro()
            time.sleep(1)
            self.driver.dist_gyro(26, direction)
            #self.driver.line_dist(23)
            time.sleep(0.5)
        
        self.current_node = next_node
        
        self.eyes.soft_reset_gyro(direction)

        if len(self.return_path) >= 3:
            self.return_path.pop()

        self.return_path.append(self.current_node)
        print(f"Return path: {self.return_path}")

        #if the current node has a room attached and there are still deliveries to make, evaluate the room
        if self.current_node in config.ATTACHED_ROOM and self.delivery_count > 0:
            print("room evaluation")
            self.eyes.set_mode("component")
            heading = config.ATTACHED_ROOM[self.current_node]
            print(self.current_node)
            print("going to room")
            if self.current_node == "NODE_4":
                self.driver.turn_pivot(heading-2)
                time.sleep(0.1)
                self.driver.readjust(heading)
                time.sleep(0.1)

                    
            else:
                self.driver.turn(heading)
            
            self.room_evaluation(35, heading)
            time.sleep(0.1)
            self.driver.exit_room(heading)
            self.driver.stop()
            time.sleep(0.1)
            print("room evaluation done")

        return True
    
    def delivery_decision(self, heading, bed_heading):
        
        print("Delivering package")
        
        if abs(bed_heading) < 15:
            self.eyes.turn_color_motor(75)
            time.sleep(0.3)
            self.driver.drive_distance(-15, 20)
            time.sleep(2.5)
            self.hands.drop_package()
            self.hands.delivery_sound()
            time.sleep(0.5)
            self.driver.drive_distance(18, 20)
            time.sleep(0.5)

        elif abs(bed_heading) < 45:
            if bed_heading < 0:
                self.eyes.turn_color_motor(75)
                time.sleep(0.3)
                self.driver.turn(heading + 7)
                time.sleep(0.5)
            else:
                self.eyes.turn_color_motor(-82)
                time.sleep(0.3)
                self.driver.turn(heading - 7)
                time.sleep(0.5)

            self.driver.drive_distance(-15, 30)
            time.sleep(1.5)
            self.hands.drop_package()
            time.sleep(0.5)
            self.hands.delivery_sound()
            time.sleep(0.5)
            self.driver.drive_distance(20,30)
            time.sleep(0.5)
            self.driver.turn(heading)
            time.sleep(1)

        else:
            if bed_heading < 0:
                self.eyes.turn_color_motor(75)
                time.sleep(0.3)
                self.driver.turn(heading + 12)
                time.sleep(0.5)
            else:
                self.eyes.turn_color_motor(-82)
                time.sleep(0.3)
                self.driver.turn(heading - 12)
                time.sleep(0.5)

            self.driver.drive_distance(-14, 30)
            time.sleep(1)
            self.hands.drop_package()
            time.sleep(0.5)
            self.hands.delivery_sound()
            time.sleep(0.5)
            self.driver.drive_distance(18,30)
            time.sleep(0.5)
            self.driver.turn(heading)
            time.sleep(0.5)
        
        self.delivery_count -= 1
        self.driver.drive_distance(10, 25)

    def room_evaluation (self,max_dist, heading):
        """Switch to RGB mode, goes to the bed and scan bed"""

        self.driver.stop()
        self.eyes.set_mode("component")
        time.sleep(0.5)
        
        early_color = self.eyes.get_red_or_green()
        if early_color ==  "GREEN":
            self.driver.stop()
            self.delivery_decision(heading, 0)
            return early_color, 0
        
        elif early_color == "RED":
            self.driver.stop()
            self.eyes.turn_color_motor(75)
            time.sleep(0.1)
            self.driver.drive_distance(10, 20)
            time.sleep(0.5)
            return early_color, 0
        
        if not self.eyes.is_room():
            while not self.eyes.is_door():
                self.driver.follow_line_gyro(heading)
                time.sleep(0.01)
        else:
            self.driver.drive_distance(10, 20)
            time.sleep(0.5)
        
        print("start sweeping")
        current_target = 75
        self.eyes.turn_color_motor(current_target)
        time.sleep(0.01)

        self.driver.left_motor.reset_encoder()
        target_deg = (max_dist / config.WHEEL_CIRCUMFERENCE) * 360
        
        #if abs(heading- self.driver.gyro_sensor.get_abs_measure()) <= 5:
#             gyro_heading2 = self.driver.gyro_sensor.get_abs_measure()
        #else:
            #gyro_heading2 = heading

        while abs(self.driver.left_motor.get_encoder()) < target_deg:
            self.driver.follow_line_gyro(heading)
            
            motor_pos = self.eyes.color_motor.get_encoder()
            if abs(current_target - motor_pos) <= 5:
                current_target *= -1
                self.eyes.turn_color_motor(current_target)

            color = self.eyes.get_red_or_green()

            if color == "GREEN":
                self.driver.stop()
                time.sleep(0.01)
                self.delivery_decision(heading, motor_pos)
                return color, motor_pos
            
            elif color == "RED":
                self.driver.stop()
                self.eyes.turn_color_motor(75)
                time.sleep(0.1)
                self.driver.drive_distance(10,20)
                time.sleep(0.5)
                return color, motor_pos

            time.sleep(0.01)
        self.eyes.turn_color_motor(75)
        self.driver.stop()
        return None, None

    def execute_mission(self):
        """Master loop for the whole mission"""

        while self.delivery_count > 0:
            if not self.execute_next_step():
                print("Route exhausted, deliveries remaining:", self.delivery_count)
                break
            time.sleep(0.1)

    def return_mission (self):
        """Returns to pharmcay"""
        #reverses the return path and use "map" to return
        #if next node is 0 (pharmacy) follow_until_door
        print("Delivered all packages")
        print("Returning to pharmacy")

        #reverse the return path to get the route back to the pharmacy
        return_route = self.return_path[::-1]

        self.eyes.turn_color_motor(0)
        self.current_node = return_route.pop(0)

        #follows route until the next node is the pharmacy (NODE_0)
        while len(return_route) > 0 and return_route[0] != "NODE_0":

            next_node = return_route.pop(0)

            #get distance and direction to next node from map
            distance, direction = self.get_path_info(self.current_node, next_node)

            print(f"Moving from {self.current_node} to {next_node} with distance {distance} and direction {direction}")

            #turn and follow line to next node
            if next_node == "NODE_1":
                self.driver.turn_pivot(direction)
            
            else:
                self.driver.turn(direction)
                
            if distance <= 15:
                self.driver.dist_gyro(19, direction)
            else:
                self.driver.follow_until_node(distance)
                self.driver.dist_gyro(25, direction)
#                 self.driver.line_dist(24)
            time.sleep(0.5)

            self.current_node = next_node
            self.eyes.soft_reset_gyro(direction)
        
        if not return_route:
            print("Already at pharmacy node")
            return
        
        final_node = return_route.pop(0)
        print("Next node is pharmacy")

        distance, direction = self.get_path_info(self.current_node, final_node)
        self.eyes.set_mode('component')
        self.driver.turn(direction)
        while not self.eyes.is_door():
            self.driver.follow_line_gyro(direction)
            time.sleep(0.01)
        self.driver.stop()
        time.sleep(0.5)
        self.driver.enter_pharmacy()
        self.hands.mission_complete_sound()
        time.sleep(0.3)
        self.driver.stop()
        

# Things to improve:
# 1. self.gyro_sensor does not exist here
# 2. Arguments issues in multiple functions
# 3. Use execute_next_step in return_mission
# 4. error handling in return mission
# 5. find a way to exit while loop in room_evaluation
# 6. DOuble room problem (extract number of beds in the room) 

