"""Hardware configurations and global constants used."""

from utils.brick import EV3ColorSensor, EV3UltrasonicSensor, Motor, EV3GyroSensor
from utils import sound
import math

#sensors and motors
COLOR_SENSOR = EV3ColorSensor(3) #can be changed to any port
US_SENSOR = EV3UltrasonicSensor (4) #can be changed to any other port
GYRO_SENSOR = EV3GyroSensor(2) #can be changed to any other port
RIGHT_MOTOR = Motor('B')
LEFT_MOTOR = Motor('A')
PICK_UP_MOTOR = Motor('C')
COLOR_MOTOR = Motor('D')

#color constants
RED = [0.8237, 0.1022, 0.0741] #mean rgb values of color red from test

ORANGE = [0.7113, 0.2328, 0.0559] #random values that need to be changed based on test
GREEN = [0.3868, 0.5234, 0.0899] #random values that need to be changed based on test
YELLOW = [0.560, 0.374, 0.067] #mean rgb values of color yellow from test
WHITE_INTENSITY = 100
BLACK_INTENSITY = 4
BED_COLORS = ['GREEN', 'RED']

LINE_TARGET = (WHITE_INTENSITY + BLACK_INTENSITY) / 2
BLACK_LINE_THRESHOLD = 12
WHEEL_CIRCUMFERENCE = math.pi * 4.2
KP = 0.05 # can be changed
KP_TURN = 1.5 #
KP_GYRO = 1
SWEEP_ANGLE = 75

BASE_SPEED = 20
PICK_UP_SPEED = 60
DROP_SPEED = 60
COLOR_MOTOR_SPEED = 30
MIN_ABS_SPEED = -5
MAX_ABS_SPEED = -100
SLOW_SPEED = 20
TURN_MIN_SPEED = -50
TURN_MAX_SPEED = 50

STOP_MIN_DIST = 5
STOP_MAX_DIST = 15
EPSILON = 0.0001
DIST_THRESH = 0.06

HOSPITAL_GRAPH = {"NODE_0":{"NODE_1": (18, 270)}, "NODE_1": {"NODE_0": (2, 90), "NODE_2": (18, 0)}, "NODE_2": {"NODE_1": (10, 180), "NODE_3": (10, 0)}, "NODE_3": {"NODE_1": (20, 180),"NODE_2":(10, 180), "NODE_4": (24, 0)}, "NODE_4": {"NODE_1": (40, 180),"NODE_3":(24, 180)}}
# format: {node1: {node2: (distance, direction),...}, ...}

MISSION_ROUTE = ["NODE_1", "NODE_2", "NODE_3", "NODE_4"]
#nodes to visit in order

ATTACHED_ROOM ={"NODE_1": 270, "NODE_2": 270, "NODE_3": 90, "NODE_4": 90}
#format: {node: heading to turn to face the bed, ...}

DELIVERY_SOUND = sound.Sound (duration=0.5, pitch="C5", volume=100)
MISSION_COMPLETE_SONG = [("C4", 0.3), ("E4", 0.3), ("G4", 0.3), ("C5", 0.3)]


#Grouping constants here:
#Hardware constants: sensors and motors
#Color detection constants: RGB and thresholds
#Line following and driving constants
#Motor speed constants
#Map and mission data
#Sound

#Missing constants:
# YELLOW
# DIST_BED (never used) -
# SAMPLE_SIZE (never used) -
# SWEEP_ANGLE (never used) -
# DIST_WALL_CLOSE (never used) -
# drive motors
# pick up motors
# color motor
# MIN_TURN_SPEED
# MAX_TURN_SPEED
# all magic numbers used in all files
# lowercase should be uppercase
# hospital graph issue with accessing values
