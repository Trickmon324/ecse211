"""Test the gyro sensor's ability to measure angles."""


import time
from utils.brick import wait_ready_sensors, reset_brick, EV3GyroSensor

GYRO_SENSOR = EV3GyroSensor (3)

print("Program start.\nWaiting for sensors to turn on...")

wait_ready_sensors(True)
print("Done waiting.")

GYRO_SENSOR_TEST_FILE = "../data_analysis/gyro_angle_test.csv"

target_angles = [90, 180, 270, 360]
NUM_TARGET = 10

input("Reset to zero.")
GYRO_SENSOR.reset_measure()

try:
    with open(GYRO_SENSOR_TEST_FILE, "w") as f:

        for target_angle in target_angles:
            for i in range(NUM_TARGET):
                

                input(f"Align to {target_angle} degrees and press enter: ")
                time.sleep(0.5)

                angle = GYRO_SENSOR.get_abs_measure()

                print(f"Angle: {angle}")
                f.write(f"{angle}\n")

except FileNotFoundError:
    print(f"File directory not found")

except KeyboardInterrupt:
    print("Program stopped by user.")

except BaseException as e:
    print(f"An unexpected error occurred: {e}")

finally:
    print("Done")
    reset_brick()
    exit()
