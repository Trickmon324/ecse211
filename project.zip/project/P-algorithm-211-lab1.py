# from utils.brick import Motor, EV3UltrasonicSensor, wait_ready_sensors, reset_brick
# from collections import deque
# import time
#
#
# # Devices
# ultra = EV3UltrasonicSensor(1)
#
# right_motor = Motor("A")
# left_motor = Motor("D")
#
# wait_ready_sensors()
#
# BAND_CENTER = 45
# BAND_WIDTH  = 5 # 3 worked intiially
#
# BASE_POWER = 25
# CORRECTION = 30
#
# distance_list = deque(maxlen=3)
#
# def get_distance():
#     distance = ultra.get_cm()
#
#     if distance is None:
#         distance = 255
#
#     distance_list.append(distance)
#     values = sorted(distance_list)
#
#     return values[len(values) // 2]
#
# try:
#     while True:
#
#         distance = get_distance()
#         print("Distance:", distance)
#         if distance > BAND_CENTER:
#             delta_distance = abs(distance - BAND_CENTER)
#             delta_distance = min(delta_distance, 40)
#             left_motor.set_power(BASE_POWER +delta_distance)
#             right_motor.set_power(BASE_POWER -delta_distance)
#         elif distance < BAND_CENTER:
#             delta_distance = abs(distance - BAND_CENTER)
#             delta_distance = min(delta_distance, 40)
#             left_motor.set_power(BASE_POWER - delta_distance)
#             right_motor.set_power(BASE_POWER + delta_distance)
#         else:
#             left_motor.set_power(BASE_POWER)
#             right_motor.set_power(BASE_POWER)
#         time.sleep(.05)
#
# except KeyboardInterrupt:
#     print("Stopping robot")
# finally:
#     reset_brick()
#


from utils.brick import Motor, EV3UltrasonicSensor, wait_ready_sensors, reset_brick
from collections import deque
import time

# --- HARDWARE SETUP ---
ultra = EV3UltrasonicSensor(1)
left_motor = Motor("A")  # Inner wheel
right_motor = Motor("D")  # Outer wheel

wait_ready_sensors()

# --- P-TYPE PARAMETERS ---
BAND_CENTER = 30
BASE_POWER = 20

# Tuning multipliers for asymmetric steering
KP_MILD_LEFT = 0.3  # Linear multiplier for gradual left turns
KP_SHARP_RIGHT = 0.07  # Exponential multiplier for sharp right turns

distance_list = deque(maxlen=5)


def get_filtered_distance():
    """Reads sensor and returns the median of the last 3 readings to filter noise."""
    distance = ultra.get_cm()
    if distance is None:
        distance = 255
    distance_list.append(distance)

    values = sorted(distance_list)
    return values[len(values) // 2]



def p_type(distance, center):
    if distance > 60:
        distance = 60
    
    # 2. Calculate the error
    error = distance - center
    
    correction = min(25, abs(error))
    
    if error > 0:
        return correction
    return -correction*1.5
    

def p_type_old(distance, center, kp_mild, kp_sharp):
    """
    Evaluates the distance and calculates proportional adjustments.
    Returns a tuple: (left_wheel_adjustment, right_wheel_adjustment)
    """
    # 1. THE 255 GAP FIX: Cap the maximum distance
    # If the sensor sees the abyss (e.g. 255cm), we treat it as 60cm
    # so the math doesn't explode and cause a violent spin.
    if distance > 60:
        distance = 60

    # 2. Calculate the error
    error = distance - center

    if error == 0:
        # Perfect distance, no adjustment needed
        return (0, 0)

    elif error > 0:
        # --- STATE 1: TOO FAR (Steer Left) ---
        # We use linear math (error * Kp) for a smooth, gradual curve
        correction = error * kp_mild

        # Max cap of 10. (e.g. Base 25 - 10 = 15. The wheel never stops spinning forward!)
        correction = min(correction, 15)

        # To turn left: slow down the left wheel, speed up the right wheel
        return (-correction, correction)

    elif error < 0:
        # --- STATE 2: TOO CLOSE (Steer Right) ---
        # We use exponential math (error^2 * Kp) to panic-brake if it gets too close!
        abs_error = abs(error)
        correction = (abs_error ** 2) * kp_sharp

        # Max cap of 30. (e.g. Base 25 - 30 = -5. The wheel will slightly reverse to pivot hard!)
        correction = min(correction, 40)

        # To turn right: speed up the left wheel, slow down the right wheel
        return (correction, -correction)

# --- MAIN LOOP ---
try:
    print("Starting Modular P-Type Controller...")
    while True:
        # 1. Get the sensor data
        current_distance = get_filtered_distance()
        print(f"Distance: {current_distance}")

        # 2. Calculate the logic (Returns adjustments for both wheels)
#         left_adj, right_adj = p_type(current_distance, BAND_CENTER, KP_MILD_LEFT, KP_SHARP_RIGHT)
        correction = p_type(current_distance, BAND_CENTER)

        # 3. Apply to hardware
        left_motor.set_power(BASE_POWER)
        right_motor.set_power(BASE_POWER + correction)

        time.sleep(0.05)

except KeyboardInterrupt:
    print("Stopping robot")
finally:
    reset_brick()