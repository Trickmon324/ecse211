import time

import config

class Driver:

    def __init__ (self, right_motor, left_motor, gyro_sensor, eyes_obj):
        #to fix: initialize all constants here instead of writing config.something later on

        self.right_motor = right_motor
        self.left_motor = left_motor
        self.kp = config.KP
        self.speed = config.BASE_SPEED
        self.gyro_sensor = gyro_sensor
        self.eyes_obj = eyes_obj
        self.wheel_circumference = config.WHEEL_CIRCUMFERENCE
        self.kp_turn = config.KP_TURN
        self.kp_gyro = config.KP_GYRO

    def _dist_to_degrees (self, dist):
        """Helper function to convert distance to degrees for the motors"""

        return (dist / self.wheel_circumference) * 360

    def _clamp_speed(self, value, min_val, max_val):
        """Clamps a value between a minimum and maximum value"""
        return max(min_val, min(value, max_val))

    def stop (self):
        """Stops motors"""

        self.left_motor.set_power(0)
        self.right_motor.set_power(0)

    def set_power(self, power):
        """Sets power to both motors"""
        self.left_motor.set_power(power)
        self.right_motor.set_power(power)


    def drive_distance (self, dist, speed):
        """Drive a certain distance"""
        #convert distance to degrees
        target_deg = self._dist_to_degrees(dist)
        self.left_motor.set_limits(power = speed)
        self.right_motor.set_limits(power = speed)
        time.sleep(0.01)
        self.left_motor.set_position_relative(target_deg)
        self.right_motor.set_position_relative(target_deg)

        #wait until motors are stopped
        self.left_motor.wait_is_stopped()
        self.right_motor.wait_is_stopped()
        time.sleep(0.1)

    def turn (self, target_heading):
        """Use Gyro sensor to turn a specific angle"""

        while True:
            current_angle = self.eyes_obj.get_corrected_heading()
            
            print (f"Turning to {target_heading}, current angle: {current_angle}")
            # calculate error and turn speed
            error = target_heading - current_angle
            
            # for shortest turn direction
            error = (error + 180) % 360 - 180

            #stop if within 1 degree of target
            if abs(error) <= 2:
                self.stop()
                break
                
            #change speed based on error
            turn_speed = self._clamp_speed(error * self.kp_turn, -40, 40)

            # if turn speed is too small, set it to 10
            if 0 < abs(turn_speed) < 15:
                if turn_speed > 0:
                    turn_speed = 15
                else:
                    turn_speed = -15

            self.left_motor.set_power(power = -turn_speed)
            self.right_motor.set_power(power = turn_speed)

            time.sleep(0.01)
        time.sleep(0.1)

    def follow_line (self, current_light):
        """Line follower logic"""

        error = current_light - config.LINE_TARGET
        turn_rate = error * self.kp

        self.left_motor.set_power (power = self._clamp_speed(-(self.speed - turn_rate), -100, -5))
        self.right_motor.set_power (power = self._clamp_speed(-(self.speed + turn_rate), -100, -5))


    def follow_until_node (self, dist):
        """Follows line until it sees a node"""

        #convert distance to degrees
        target_deg = self._dist_to_degrees(dist)
        blind_deg = target_deg * 0.7
        self.left_motor.reset_encoder()

        while True:
            current_deg = abs(self.left_motor.get_encoder())
            current_light = self.eyes_obj.get_light_intensity()

            print(f"Current light: {current_light}")
            
            #follows line blindly
            if current_deg < blind_deg:

                self.follow_line(current_light)
            else:

                #actively check for intersection (node)
                if self.eyes_obj.is_intersection():
                    print("Intersection detected")
                    self.stop()
                    break
                else:
                    self.follow_line(current_light)

            time.sleep(0.01)
            
    def line_dist(self, dist):
        target_deg = abs(self._dist_to_degrees(dist))
        self.left_motor.reset_encoder()
        
        time.sleep(0.01)
        while abs(self.left_motor.get_encoder()) < target_deg:
            current_light = self.eyes_obj.get_light_intensity()
            self.follow_line(current_light)
            time.sleep(0.01)
        
    def follow_line_gyro(self, heading, reverse = False):
        """Follows line using gyro sensor to maintain heading"""
        
        current_heading = self.eyes_obj.get_corrected_heading()
        print(current_heading)
        error = heading - current_heading
        error = (error + 180) % 360 - 180

        turn_speed = error * self.kp_gyro #put this in kp_gyro

        if reverse:
            self.left_motor.set_power(power = self._clamp_speed((self.speed - turn_speed), 5, 100))
            self.right_motor.set_power(power = self._clamp_speed((self.speed + turn_speed), 5, 100))
        else:
            self.left_motor.set_power(power = self._clamp_speed(-(self.speed + turn_speed), -100, -5))
            self.right_motor.set_power(power = self._clamp_speed(-(self.speed - turn_speed), -100, -5))
            

    def exit_room (self, heading):
        """Reverses out of the room until it sees a node after a completed delivery"""
        while not self.eyes_obj.is_door():
            self.follow_line_gyro(heading, reverse = True)
            time.sleep(0.01)
            
        self.drive_distance(-2, 20)
        time.sleep(0.5)
        self.eyes_obj.set_mode("red")
        self.stop()
        
    def dist_gyro(self, dist, heading):
        is_reverse = dist < 0
        target_deg = abs(self._dist_to_degrees(dist))
        
        self.left_motor.reset_encoder()
        time.sleep(0.01)
        #if abs(self.gyro_sensor.get_abs_measure() - heading) <=3:
            #new_heading = self.gyro_sensor.get_abs_measure()
        #else:
            #new_heading = heading
        
        while abs(self.left_motor.get_encoder()) < target_deg:
            self.follow_line_gyro(heading, reverse=is_reverse)
            time.sleep(0.01)
        
        self.stop()
        time.sleep(0.1)
        
    def turn_pivot(self, heading):
        """Turn around a wheel pivot"""
        current_angle = self.eyes_obj.get_corrected_heading()
        error = heading - current_angle
        error = (error + 180) % 360 - 180

        if error > 0:
            self.left_motor.set_power(power = -40)
            self.right_motor.set_power(power = 0)
        else:
            self.left_motor.set_power(power = 0)
            self.right_motor.set_power(power = -40)
        time.sleep(0.01)
        
        while True:
            current_angle = self.eyes_obj.get_corrected_heading()
            error = heading - current_angle
            error = (error + 180) % 360 - 180
            time.sleep(0.01)

            if abs(error) <= 3:
                self.stop()
                break

            time.sleep(0.01)

    def enter_pharmacy(self):
        self.eyes_obj.set_mode("component")
        while not self.eyes_obj.is_door():
            self.follow_line_gyro(90)
            time.sleep(0.01)
        self.stop()
        time.sleep(0.5)
        self.eyes_obj.turn_color_motor(85)
        time.sleep(0.5)
        self.dist_gyro(20,90)
        time.sleep(1)
        self.turn_pivot(90 + 45)
        time.sleep(1)
        self.drive_distance(-8, 20)
        time.sleep(2)
        self.turn_pivot(180)
        time.sleep(1)
        self.drive_distance(10,20)
        time.sleep(1)
        self.stop()

    def readjust(self, heading):
        self.turn(heading + 37)
        time.sleep(1)
        self.drive_distance(12,20)
        time.sleep(2)
        self.turn(heading + 2)
        self.eyes_obj.turn_color_motor(0)
        time.sleep(1)

#improvements for driver.py
#1. helper function to compute the turn correction for the gyro sensor...

#3. Maybe find a way to combine follow_until_node and follow_to_door...

#6 Magic numbers should be constants...
