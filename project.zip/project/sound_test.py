import subprocess

def play_sound_test():
    subprocess.run(["amixer", "sset", "Master", "55%"], stdout=subprocess.DEVNULL)
    
    subprocess.Popen(["aplay", "-d", "20", "/home/pi/Music/audio2.wav"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    

play_sound_test()