"""
This program plays notes based on the color of the cube detected by the color sensor and the touch sensors.
"""

import time
import math
from config import * #imports all the constants and sensors
from statistics import stdev
import sys
from utils.brick import wait_ready_sensors, reset_brick

def collect_color_sensor_data(red, green, blue):
    "Collect color sensor data."

    rgb_stats = COLOR_SENSOR.get_rgb() #get rgb data

    #if no data is returned, return None
    if not rgb_stats:
        return None
    
    r,g,b = rgb_stats
    denominator = r + g + b + EPSILON
    #prevent division by zero

    red.append (r/denominator)
    green.append(g/denominator)
    blue.append(b/denominator)

    #remove the oldest value if the list is too long
    if len(red) > SAMPLE_SIZE:
        red.pop(0)
        green.pop(0)
        blue.pop(0)
    
    #if the list is not full, return None
    if len(red) < SAMPLE_SIZE:
        return None
    
    #if the standard deviation is too high, return "unstable"
    if stdev(red) > DEV_THRESH or stdev(green) > DEV_THRESH or stdev(blue) > DEV_THRESH:
        return "unstable"
    
    #calculate the mean of the rgb values
    red_mean = round(sum(red) / len(red), 3)
    green_mean = round(sum(green) / len(green), 3)
    blue_mean = round(sum(blue) / len(blue), 3)

    point = [red_mean, green_mean, blue_mean]

    #calculate the distance between the mean rgb values and the red and blue rgb values
    dist_red = math.dist(RED, point)
    dist_blue = math.dist(BLUE, point)

    print(f"Norm RGB: {point}, Red distance: {dist_red:.3f}, Blue distance: {dist_blue:.3f}")

    #return the color of cube detected
    if dist_red < DIST_THRESH and dist_red < dist_blue:
        return "red"
    elif dist_blue < DIST_THRESH and dist_red > dist_blue:
        return "blue"
    else:
        return "other"
    
def touch_sensor (sensor, start, trigger_flag, hold_time = HOLD_TIME_TOUCH):
    """Checks if a sensor is being held"""

    #if the sensor is pressed
    if sensor.is_pressed():
        #if the timer hasn't already started
        if start is None:
            start = time.time()
            trigger_flag = False

        #if the sensor has been held for the hold time
        if time.time() - start >= hold_time and not trigger_flag:
            trigger_flag = True

            return start, trigger_flag, True

        return start, trigger_flag, False
    
    else:
        return None, False, False


# def play_note(note):
#     note.play()


# def flute_loop():

#     touch1_start = None #initializes the first touch timer
#     touch2_start = None #initializes the second touch timer
#     touch1_triggered = False # True = touch sensor 1 has been triggered, False = touch sensor 1 has not been triggered
#     touch2_triggered = False # True = touch sensor 2 has been triggered, False = touch sensor 2 has not been triggered

#     red_sample = [] #list to store the red values
#     green_sample = [] #list to store the green values
#     blue_sample = [] #list to store the blue values

#     print("Program start.\nWaiting for sensors to turn on...")

#     wait_ready_sensors(True)
#     print("Done waiting.")

#     while True:

#         #collect data from the color sensor
#         color = collect_color_sensor_data (red_sample, green_sample, blue_sample)

#         #process the touch sensors
#         touch1_start, touch1_triggered, active1 = touch_sensor (TOUCH_SENSOR_1, touch1_start, 
#                 touch1_triggered)
        
#         touch2_start, touch2_triggered, active2 = touch_sensor (TOUCH_SENSOR_2, touch2_start,
#                     touch2_triggered)
        
#         #if the first touch sensor has been held and triggered
#         if active1:
#             touch2_start = None
#             touch2_triggered = False

#             if color == 'red':
#                 print("Red detected with touch sensor 1! Playing note 1.")
#                 play_note(NOTE1)

#             elif color == 'blue':
#                 print("Blue detected with touch sensor 1! Playing note 2.")
#                 play_note(NOTE2)
            
#         #if the second touch sensor has been held and triggered
#         elif active2:
#             touch1_start = None
#             touch1_triggered = False

#             if color == 'red':
#                 print("Red detected with touch sensor 2! Playing note 3.")
#                 play_note(NOTE3)
            
#             elif color == 'blue':
#                 print("Blue detected with touch sensor 2! Playing note 4.")
#                 play_note(NOTE4)

#         time.sleep(DELAY_SEC)
    


# if __name__ == "__main__":

#     try:
#         flute_loop()
#     except KeyboardInterrupt:
#         reset_brick()
#         sys.exit()