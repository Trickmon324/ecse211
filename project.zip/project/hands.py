import threading
import os
import time
import config
import subprocess
from utils.brick import reset_brick

class Hands:

    def __init__ (self, pick_up_motor, us_sensor, left_motor, right_motor):
        #set up motors and sensors
        #good question
        self.us_sensor = us_sensor
        self.left_motor = left_motor
        self.right_motor = right_motor
        self.pick_up_motor = pick_up_motor

    def pick_up(self):
        """Logic for picking up motor"""
        self.pick_up_motor.set_limits(power = config.PICK_UP_SPEED)
        self.pick_up_motor.set_position_relative(-200)
        time.sleep(0.01)
        self.pick_up_motor.wait_is_stopped()

    def drop_package (self):
        """Logic for droping medicine"""
        self.pick_up_motor.set_limits(power = config.PICK_UP_SPEED)
        self.pick_up_motor.set_position_relative(180)
        time.sleep(0.01)
        self.pick_up_motor.wait_is_stopped()

    def delivery_sound(self):
        """sound to play when delivery"""

        subprocess.run(["amixer", "sset", "Master", "55%"], stdout = subprocess.DEVNULL)

        #placeholder filepath and filename
        subprocess.Popen(["aplay", "-d", "3", "/home/pi/Music/mario_coin.wav"], stdout = subprocess.DEVNULL, stderr = subprocess.DEVNULL)

    def mission_complete_sound(self):
        """sound to play when mission is complete"""
        subprocess.run(["amixer", "sset", "Master", "100%"], stdout = subprocess.DEVNULL)

        #placeholder filepath and filename
        subprocess.Popen(["aplay", "-d", "7", "/home/pi/Music/audio4.wav"], stdout = subprocess.DEVNULL, stderr = subprocess.DEVNULL)

    def emergency_stop (self):
        """Starts a background thread for the emergency stop"""

        #if touch sensor is pressed, stop the motors and exit the program
        #backgroun thread to monitor touch sensor
        stop_thread =   threading.Thread(target = self.stop_trigger)
        stop_thread.daemon = True
        stop_thread.start()

    #if another mechanism to stop, can change the code
    def stop_trigger (self):
        """Monitors ultrasonic sensor for emergency stop"""

        trigger_time = None

        while True:
            try:
                dist = self.us_sensor.get_value()
            except Exception:
                time.sleep(0.05)
                continue

            if 5 < dist < 15:
                if trigger_time is None:
                    trigger_time = time.time()

                elif time.time() - trigger_time >= 0.3:
                    print("Emergency stop triggered")
                    self.left_motor.set_power(0)
                    self.right_motor.set_power(0)
                    self.pick_up_motor.set_power(0)
                    reset_brick()
                    os._exit(1)
            else:
                trigger_time = None

            time.sleep(0.05)
# Things to improve:
# 1. Left, right pick up motor 
# 2. Emergency stop needs to stop all motors including pick up motors and color motor
# 3. Random useless comments to remove


