"""This program uses the ultrasonic sensor to detect the distance between the robot and an object.
If the object is within the range of 10-25 cm, the motor will start the drum system.
If the object is within the range of 0-5 cm, the motor will stop and the system will exit."""

import time
import sys
from config import *
from utils.brick import wait_ready_sensors, reset_brick

def start_motor():
    """Starts the motor. Strikes the drum."""       
        
    #drumming part
    DRUM_MOTOR.set_dps(500)
    DRUM_MOTOR.set_position(82)

def reverse_motor():
    """Reverses the motor. Resets the drum."""
    DRUM_MOTOR.set_dps(400)
    DRUM_MOTOR.set_position(0)

def stop_all_sounds(flute_notes):
    """Stops all sounds."""
    for notes in flute_notes:
        notes.stop()

def emergency_stop(flute_notes):
    """Stops the motor and the system."""

    #stops the motor
    DRUM_MOTOR.float_motor()
    
    stop_all_sounds(flute_notes)
    #exits the system
    sys.exit()

def handle_emergency (dist, stop_hold_start, motor_hold_start, flute_notes):
    """handles emergency distance for stop"""
    
    #checks if the distance is within the emergency range
    if dist <= MAX_EMERGENCY_DIST:
        motor_hold_start = None

        if stop_hold_start is None:

            print(f"\nObject detected in range: {dist:.1f} cm")

            #start the timer for the emergency stop
            stop_hold_start = time.time()
        
        #checks if the time reached the hold time
        if time.time() - stop_hold_start >= HOLD_TIME_US:
            
            print(f"\nEmergency stop triggered. Distance: {dist:.1f} cm")

            #stops the motor and the system
            emergency_stop(flute_notes)
    else:
        stop_hold_start = None

    return stop_hold_start, motor_hold_start

def drum_trigger (dist, motor_hold_start, stop_hold_start):
    """Processes distance to trigger drum"""
    trigger = False
    
    #checks if the distance is within the motor range
    if MIN_MOTOR_DIST <= dist <= MAX_MOTOR_DIST:
        stop_hold_start = None

        if motor_hold_start is None:

            print(f"\nObject detected in range: {dist:.1f} cm")

            #start the timer for the motor
            motor_hold_start = time.time()
        
        #checks if the time reached the hold time
        if time.time() - motor_hold_start > HOLD_TIME_US:
            
            trigger = True

            print(f"\nDrum triggered. Distance: {dist:.1f} cm")
            
    else:
        motor_hold_start = None

    return motor_hold_start, stop_hold_start, trigger

def us_sensor():
    
    DRUM_MOTOR.reset_encoder() #resets the encoder

    drumming_phase = 0 # 0: Start. 1:Reverse, 2:Reset
    stop_hold_start = None #initializes the stop timer
    motor_hold_start = None #initializes the motor timer
    motor_state = False # False = not drumming, True = drumming active

    print("Program start.\nWaiting for sensors to turn on...")

    wait_ready_sensors(True)
    print("Done waiting.")

    while True:

        #gets the distance from the ultrasonic sensor
        dist = US_SENSOR.get_value()

        print(f"Current Distance: {dist:.1f} cm", end='\r')

        #handles the emergency stop
        stop_hold_start, motor_hold_start = handle_emergency(dist, stop_hold_start, motor_hold_start, NOTES)

        #only call drum_trigger when motor is not drumming
        if not motor_state:
            motor_hold_start, stop_hold_start, trigger_now = drum_trigger(dist, motor_hold_start, stop_hold_start)

            if trigger_now:
                motor_state = True
                drumming_phase = 0 #ensures it starts at 0
                print("Motor On")

        #starts the drumming cycle
        if motor_state:
            
            if drumming_phase == 0:
                start_motor()
                print("Forward")
                print(f"Drumming phase: {drumming_phase}")
            
                drumming_phase = 1
                
            elif drumming_phase == 1:

                #checks if the drum hit the target
                if not DRUM_MOTOR.is_moving():

                    #reverse the motor
                    reverse_motor()
                    print("Backward")
                    print(f"Drumming phase: {drumming_phase}")
                    drumming_phase = 2

            elif drumming_phase == 2:

                #checks if the drum has fully reversed
                if not DRUM_MOTOR.is_moving():
                    print("Drumming cycle reset")
                    print(f"Drumming phase: {drumming_phase}")
                    #reset the drumming cycle
                    drumming_phase = 0


        time.sleep(DELAY_SEC) #small delay to prevent high CPU usage 


if __name__ == "__main__":
    
    try:
        us_sensor()
    except KeyboardInterrupt:
        reset_brick()
        sys.exit()