from utils.brick import Motor, EV3ColorSensor, EV3GyroSensor, EV3UltrasonicSensor, wait_ready_sensors, reset_brick
import time
import math

PICK_UP_MOTOR = Motor('C')
LEFT_MOTOR = Motor('B')
RIGHT_MOTOR = Motor('A')
WHEEL_CIRCUMFERENCE = math.pi * 4.2
KP_TURN = 3

GYRO_SENSOR = EV3GyroSensor('2')

def drive_distance (dist, speed):
    target_deg = (dist / WHEEL_CIRCUMFERENCE) * 360
    
    LEFT_MOTOR.set_limits (power = speed)
    RIGHT_MOTOR.set_limits (power = speed)
    
    LEFT_MOTOR.set_position_relative(target_deg)
    RIGHT_MOTOR.set_position_relative(target_deg)
    time.sleep(0.1)
    
    LEFT_MOTOR.wait_is_stopped()
    RIGHT_MOTOR.wait_is_stopped()

def delivery ():
    PICK_UP_MOTOR.set_limits(power = 60)
    PICK_UP_MOTOR.set_position_relative(180)
    time.sleep(0.01)
    PICK_UP_MOTOR.wait_is_stopped()
    
if __name__ == "__main__":
    try:
        delivery()
        time.sleep(1)
        drive_distance(8, 50)
        
        
    except KeyboardInterrupt:
        pass
    finally:
        LEFT_MOTOR.set_power(0)
        RIGHT_MOTOR.set_power(0)
        PICK_UP_MOTOR.set_power(0)
        reset_brick()