# from utils.brick import Motor, EV3UltrasonicSensor, wait_ready_sensors, reset_brick
# from collections import deque
# import time
#
#
# # Devices
# ultra = EV3UltrasonicSensor(1)
#
# left_motor = Motor("D")
# right_motor = Motor("A")
#
# wait_ready_sensors()
#
# BAND_CENTER = 30
# BAND_WIDTH  = 5 # 3 worked intiially
#
# BASE_POWER = 25
# CORRECTION = 20
#
# distance_list = deque(maxlen=3)
#
# def get_distance():
#     distance = ultra.get_cm()
#
#     if distance is None:
#         distance = 255
#
#     distance_list.append(distance)
#     values = sorted(distance_list)
#
#     return values[len(values) // 2]
#
# try:
#     while True:
#
#         distance = get_distance()
#         print("Distance:", distance)
#         if distance > BAND_CENTER + BAND_WIDTH:
#             left_motor.set_power(BASE_POWER+CORRECTION)
#             right_motor.set_power(BASE_POWER-CORRECTION)
#         elif distance < BAND_CENTER - BAND_WIDTH:
#             left_motor.set_power(BASE_POWER - CORRECTION)
#             right_motor.set_power(BASE_POWER+CORRECTION)
#         else:
#             left_motor.set_power(BASE_POWER)
#             right_motor.set_power(BASE_POWER)
#         time.sleep(.05)
#
# except KeyboardInterrupt:
#     print("Stopping robot")
# finally:
#     reset_brick()


from utils.brick import Motor, EV3UltrasonicSensor, wait_ready_sensors, reset_brick
from collections import deque
import time

# --- HARDWARE SETUP ---
ultra = EV3UltrasonicSensor(1)
left_motor = Motor("A")  # Inner wheel
right_motor = Motor("D")  # Outer wheel

wait_ready_sensors()

# --- PARAMETERS ---
BAND_CENTER = 30
BAND_WIDTH = 5
BASE_POWER = 25
CORRECTION = 25  # If BASE_POWER is 25, subtracting this makes the wheel stop!

distance_list = deque(maxlen=5)


def get_filtered_distance():
    """Reads sensor and returns the median of the last 3 readings to filter noise."""
    distance = ultra.get_cm()
    if distance is None:
        distance = 255
    distance_list.append(distance)

    values = sorted(distance_list)
    return values[len(values) // 2]


def bang_bang(distance, center, width, correction_amount):
    """
    Evaluates the distance and returns the required power adjustment.
    Positive value = Add power (speed up)
    Negative value = Remove power (slow down)
    Zero = No action
    """
    if distance > (center + width):
        # Too far: return positive correction to speed up the outer wheel
        return correction_amount

    elif distance < (center - width):
        # Too close: return negative correction to slow down the outer wheel
        return -correction_amount

    else:
        # Within the acceptable band: return 0 (no correction)
        return 0


# --- MAIN LOOP ---
try:
    print("Starting Modular Bang-Bang Controller...")
    while True:
        # 1. Get the sensor data
        current_distance = get_filtered_distance()

        # 2. Calculate the logic (Separated from hardware!)
        power_adjustment = bang_bang(current_distance, BAND_CENTER, BAND_WIDTH, CORRECTION)

        # 3. Apply to hardware
        # Inner wheel (Left) always stays constant at BASE_POWER
        # Outer wheel (Right) gets the adjustment
        left_motor.set_power(BASE_POWER)
        right_motor.set_power(BASE_POWER + power_adjustment)

        time.sleep(0.05)

except KeyboardInterrupt:
    print("Stopping robot")
finally:
    reset_brick()