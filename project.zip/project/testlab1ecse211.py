from collections import deque
from utils.brick import Motor, EV3UltrasonicSensor, wait_ready_sensors, reset_brick
import time

import utils.brick

ultra = EV3UltrasonicSensor(1)
wait_ready_sensors()
ultra.get_raw_value() # this is the thing that gets distance

left_motor = Motor("D")
right_motor = Motor("A")
while (True):
     print(ultra.get_raw_value())
     time.sleep(.01)
left_motor.set_power(50)
right_motor.set_power(100)
left_motor.set_dps(200)
right_motor.set_dps(200)
time.sleep(5)
left_motor.set_dps(0)
right_motor.set_dps(0)
dq_list = deque(maxlen=5)

dq_list.append(5)
dq_list.append(4)
dq_list.append(3)
dq_list.append(2)
print(dq_list)
dq_list.append(1)
dq_list.append(0)

print(dq_list)

