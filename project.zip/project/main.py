"""This file is used to run the robot"""

from driver import Driver
from eyes import Eyes
from hands import Hands
from brain import Brain
from utils.brick import wait_ready_sensors, reset_brick
import config

eyes = Eyes(config.COLOR_SENSOR, config.US_SENSOR, config.GYRO_SENSOR, config.COLOR_MOTOR)
driver = Driver(config.RIGHT_MOTOR, config.LEFT_MOTOR, config.GYRO_SENSOR, eyes)
hands = Hands(config.PICK_UP_MOTOR, config.US_SENSOR, config.LEFT_MOTOR, config.RIGHT_MOTOR )
brain = Brain(driver, eyes, hands)

def main_loop():
    try:
        wait_ready_sensors(True)
        hands.emergency_stop()
        
        brain.set_up()
        #driver.turn(90)
        brain.execute_mission()
        brain.return_mission()

    except KeyboardInterrupt:
        print("Mission cancelled")

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        reset_brick()

if __name__ == "__main__":
    main_loop()
