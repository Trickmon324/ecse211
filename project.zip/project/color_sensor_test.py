#!/usr/bin/env python3

"""
This test is used to collect data from the color sensor.
It must be run on the robot.
Modified version of color_touch_sensors.py to test the color sensor.
Test: determine if the color sensor can accurately return red or blue or unknown.
"""

# Add your imports here, if any
from config import *
from utils.brick import wait_ready_sensors
import time
import math

wait_ready_sensors(True) # Input True to see what the robot is trying to initialize! False to be silent.
print("Done waiting.")

#lists to store the rgb values
red = [] 
green = [] 
blue = [] 

for i in range(100): 

    rgb_stats = COLOR_SENSOR.get_rgb() #get rgb data

    #if no data is returned, continue
    if rgb_stats is None or rgb_stats[0] is None:
        time.sleep(0.1)
        continue

    r,g,b = rgb_stats
    
    denominator = r + g + b + EPSILON

    red.append (r/denominator)
    green.append(g/denominator)
    blue.append(b/denominator)

    #remove the oldest value if the list is too long
    if len(red) > SAMPLE_SIZE:
        red.pop(0)
        green.pop(0)
        blue.pop(0)

    #if the list is not full, continue
    if len(red) < SAMPLE_SIZE:
        time.sleep(0.1)
        continue

    #calculate the mean of the rgb values
    red_mean = round(sum(red) / len(red), 3)
    green_mean = round(sum(green) / len(green), 3)
    blue_mean = round(sum(blue) / len(blue), 3)

    point = [red_mean, green_mean, blue_mean]

    #calculate the distance between the mean rgb values and the red and blue rgb values
    dist_red = math.dist(RED, point)
    dist_blue = math.dist(BLUE, point)

    #print the color of cube detected
    if dist_red < DIST_THRESH and dist_red < dist_blue:
        print(f"red, Dist_red: {dist_red}, Dist_blue: {dist_blue}")
    elif dist_blue < DIST_THRESH and dist_red > dist_blue:
        print(f"blue, Dist_red: {dist_red}, Dist_blue: {dist_blue}")
    else:
        print(f"other")

    time.sleep(0.1)