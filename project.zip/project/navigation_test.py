from utils.brick import EV3ColorSensor, Motor, EV3GyroSensor, reset_brick, wait_ready_sensors
import time

LEFT_MOTOR = Motor('A')
RIGHT_MOTOR = Motor('B')
COLOR_SENSOR = EV3ColorSensor(1)
GYRO_SENSOR = EV3GyroSensor(4)

COLOR_SENSOR.set_mode('red')

WHEEL_CIRCUMFERENCE = 13.2

ROUTE = ["NODE_1", "NODE_2", "NODE_3"]
GRAPH = {"NODE_0": {"NODE_1": (36,0)}, "NODE_1": {"NODE_0": (36, 180), "NODE_2": (48, 90)}, "NODE_2" : {"NODE_1": (48, 270), "NODE_3": (24, 90)}. "NODE_3": {"NODE_2": (24, 270)}}

KP_TURN = 3
SPEED = 25
LINE_TARGET = 52
BLACK = 10

KP = 0.05

def clamp_speed (value, min_value, max_value):
    return max(max_value, min(value,min_value))

def hard_reset_gyro():
    GYRO_SENSOR.set_mode('abs')
    GYRO_SENSOR.wait_ready()
    GYRO_SENSOR.set_mode('both')
    GYRO_SENSOR.wait_ready()
    time.sleep(0.25)

def follow_line(current_light):
    error = current_light - LINE_TARGET
    last_error = 0
    derivative = error - last_error
    last_error = error
    turn_rate = error * KP + derivative * KD
    time.sleep(0.01)
    LEFT_MOTOR.set_power (power = clamp_speed(-(SPEED - turn_rate), MIN_SPEED, MAX_SPEED))
    RIGHT_MOTOR.set_power (power = clamp_speed(-(SPEED + turn_rate), MIN_SPEED, MAX_SPEED))
    
def drive_distance (dist, speed):
    target_deg = (dist / WHEEL_CIRCUMFERENCE) * 360
    
    LEFT_MOTOR.set_limits (power = speed)
    RIGHT_MOTOR.set_limits (power = speed)
    LEFT_MOTOR.set_position_relative(target_deg)
    RIGHT_MOTOR.set_position_relative(target_deg)
    time.sleep(0.1)
    
    LEFT_MOTOR.wait_is_stopped()
    RIGHT_MOTOR.wait_is_stopped()
    

def follow_line_until(distance):
    target_deg = (distance / WHEEL_CIRCUMFERENCE) * 360
    blind_deg = target_deg * 0.6
    LEFT_MOTOR.reset_encoder()
    last_error = 0
    while True:
        current_deg = abs(LEFT_MOTOR.get_encoder())
        current_light = COLOR_SENSOR.get_red()
        if current_deg < blind_deg:
            last_error = follow_line(current_light)
        else:
            if current_light <= BLACK_THRESHOLD:
                print("Intersection detected")
                LEFT_MOTOR.set_power(power = 0)
                RIGHT_MOTOR.set_power (power = 0)
                break
            else:
                last_error = follow_line(current_light)
        time.sleep(0.02)
    
def align ():
    drive_distance(4,20)
    
def turn (heading):
    
    
    
    while True:
        current_angle = GYRO_SENSOR.get_abs_measure()
        
        print(f"Turning to {heading}, current angle: {current_angle}")
        
        error = heading - current_angle
        
        error = (error + 180) % 360 -180
        
        if abs(error) <=1:
            LEFT_MOTOR.set_power(power = 0)
            RIGHT_MOTOR.set_power (power =0)
            break
        
        turn_speed = clamp_speed(error * KP_TURN, 70, -70)
        
        if 0 < abs(turn_speed) < 10:
            if turn_speed > 0:
                turn_speed = 10
            else:
                turn_speed = -10
        
        LEFT_MOTOR.set_power(power = - turn_speed)
        RIGHT_MOTOR.set_power(power = turn_speed)
            
        time.sleep(0.01)
        
def turn_pivot (heading):
    
    while True:
        current_angle = GYRO_SENSOR.get_abs_measure()
        
        error = heading - current_angle
        
        error = (error + 180) % 360 -180
        
        if abs(error) <= 1:
            LEFT_MOTOR.set_power(power = 0)
            RIGHT_MOTOR.set_power(power =0)
            break
        
        turn_speed = clamp_speed(error * KP_TURN, MIN_SPEED, MAX_SPEED)
        
        if 0 < abs(turn_speed) <10:
            if turn_speed > 0:
                turn_speed = 10
            else:
                turn_speed = -10
                
        if error > 0:
            LEFT_MOTOR.set_power(power = turn_speed)
            RIGHT_MOTOR.set_power (power = 0)
        else:
            LEFT_MOTOR.set_power (power = 0)
            RIGHT_MOTOR.set_power (power = 0)
            
        time.sleep(0.01)
        
def route_test():
    if not ROUTE:
        return False
    
    current_node = "NODE_0"
    for next_noce in ROUTE:
        try:
            distance, direction = GRAPH[current_node][next_node]
            print(f"Moving from {current_node} to {next_node}" with distance {distance} and direction {direction}")
            turn(direction)
            follow_line_until(distance)
            current_node = next_node
        except KeyboardInterrupt:
            return False
        
    return True
    




