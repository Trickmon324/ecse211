from utils.brick import EV3ColorSensor, reset_brick, Motor, wait_ready_sensors
import math
import time
from utils import sound

COLOR_SENSOR = EV3ColorSensor(3)

# Reference RGB vectors (normalized)
RED = [0.8237, 0.1022, 0.0741]
GREEN = [0.3868, 0.5234, 0.0899]
ORANGE = [0.7113, 0.2328, 0.0559]
GOOD_SOUND = sound.Sound(duration=1, pitch="C5", volume=100)
WHEEL_CIRCUMFERENCE = 13.5
RIGHT_MOTOR = Motor('A')
LEFT_MOTOR = Motor('B')

def get_red_or_green():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if not rgb_stats:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    red_dist = math.dist(RED, point)
    green_dist = math.dist(GREEN, point)
    if red_dist < green_dist and red_dist < 0.06:
        print("Red bed")
        return "RED"
    elif green_dist < red_dist and green_dist < 0.06:
        print("Green bed")
        return "GREEN"
    else:
        return None
    
def get_orange():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if not rgb_stats:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    orange_dist = math.dist(ORANGE, point)
    if orange_dist < 0.06:
        print("Orange door")
        return "ORANGE"
    else:
        return None
    
def is_door():
    door = get_orange()
    if door == "ORANGE":
        return True
    else:
        return False
    
def play_good_sound():
    GOOD_SOUND.play()
    GOOD_SOUND.wait_done()
    
def bed_evaluation():
    while True:
        bed = get_red_or_green()
        if bed == "RED":
            return "RED"
        elif bed == "GREEN":
            return "GREEN"
        
def drive_distance (dist, speed):
    target_deg = (dist / WHEEL_CIRCUMFERENCE) * 360
    
    LEFT_MOTOR.set_limits (power = speed)
    RIGHT_MOTOR.set_limits (power = speed)
    LEFT_MOTOR.set_position_relative(target_deg)
    RIGHT_MOTOR.set_position_relative(target_deg)
    time.sleep(0.1)
    
    LEFT_MOTOR.wait_is_stopped()
    RIGHT_MOTOR.wait_is_stopped()
        
if __name__ == "__main__":
    try:
        wait_ready_sensors(True)
        COLOR_SENSOR.set_mode('component')
        time.sleep(1)
        
        color = bed_evaluation()
        if color == "GREEN":
            print("green bed")
            play_good_sound()
        elif color == "RED":
            print("red bed")
            
            drive_distance(5, 15)
            print("searching for door")
            
            RIGHT_MOTOR.set_power(power=15)
            LEFT_MOTOR.set_power(power=15)
            
            while True:
                door = is_door()
                if door and is_door() == door:
                    break
                time.sleep(0.01)
            RIGHT_MOTOR.set_power(power=0)
            LEFT_MOTOR.set_power(power=0)
            
    except KeyboardInterrupt:
        print("Program interrupted")
        
    finally:
        RIGHT_MOTOR.set_power(power=0)
        LEFT_MOTOR.set_power(power=0)
        reset_brick()