from utils.brick import EV3ColorSensor, Motor, EV3GyroSensor, wait_ready_sensors, EV3ColorSensor, reset_brick, EV3UltrasonicSensor, wait_ready_sensors
import time
import threading
import os
from room_eval2 import exit_room, turn_color_motor, search_bed
from room_entry_test import follow_line_until
import math

LEFT_MOTOR = Motor('A')
RIGHT_MOTOR = Motor('B')
COLOR_SENSOR = EV3ColorSensor(3)
PICK_UP_MOTOR = Motor ('C')
US_SENSOR = EV3UltrasonicSensor(4)
COLOR_MOTOR = Motor('D')

ROUTE = ["NODE_1", "NODE_2", "NODE_3", "NODE_4"]
GRAPH = {"NODE_0": {"NODE_1": (20,0)}, "NODE_1": {"NODE_0": (20, 180), "NODE_2": (18, 90)}, "NODE_2" : {"NODE_1": (20, 270), "NODE_3": (10, 90)}, "NODE_3": {"NODE_2": (10, 270), "NODE_4":(10, 90)}, "NODE_4": {"NODE_3": (10, 270)}}
ROOMS = {"NODE_1": 0, "NODE_2": 0, "NODE_3": 180, "NODE_4": 180}

RETURN = ["NODE_0"]



#OLOR_SENSOR = EV3ColorSensor(1)
GYRO_SENSOR = EV3GyroSensor(2)

WHEEL = 13.5
ORANGE = [0.7113, 0.2328, 0.0559]
BLACK = 15
LINE_TARGET = 52
KP_GYRO = 2
KP = 0.05
KD = 0
KP_TURN = 1.1

SPEED = 27


def clamp_speed (value, min_value, max_value):
    return max(max_value, min(value,min_value))

        
def drive_distance (dist, speed):
    target_deg = (dist/WHEEL) * 360
    LEFT_MOTOR.set_limits (power = speed)
    RIGHT_MOTOR.set_limits (power = speed)
    
    LEFT_MOTOR.set_position_relative(target_deg)
    RIGHT_MOTOR.set_position_relative(target_deg)
    time.sleep(0.1)
    LEFT_MOTOR.wait_is_stopped()
    RIGHT_MOTOR.wait_is_stopped()
    
def reset_gyro():
    GYRO_SENSOR.set_mode('abs')
    GYRO_SENSOR.wait_ready()
    GYRO_SENSOR.set_mode('both')
    GYRO_SENSOR.wait_ready()
    time.sleep(0.01)
    
def turn (heading):
    
    
    while True:
        current_angle = GYRO_SENSOR.get_abs_measure()
        
        print(f"Turning to {heading}, current angle: {current_angle}")
        
        error = heading - current_angle
        
        error = (error + 180) % 360 -180
        
        if abs(error) <=5:
            LEFT_MOTOR.set_power(power = 0)
            RIGHT_MOTOR.set_power (power =0)
            break
        
        turn_speed = clamp_speed(error*KP_TURN, 50, -50)
        
        if 0 < abs(turn_speed) < 15:
            if turn_speed > 0:
                turn_speed = 15
            else:
                turn_speed = -15
                
        
        
        LEFT_MOTOR.set_power(power = -turn_speed)
        RIGHT_MOTOR.set_power(power = turn_speed)
            
        time.sleep(0.01)
        
        
def stop():
    sthread = threading.Thread(target = stop_trigger)
    sthread.daemon = True
    sthread.start()
    
    
def stop_trigger():
    trigger_time = 0
    while True:
        try:
            value = US_SENSOR.get_value()
        except Exception:
            time.sleep(0.01)
            continue
        print(value)
        if 5.0 < value < 15.0:
            if trigger_time is None:
                trigger_time= time.time()
        
            elif time.time() - trigger_time>= 0.5:
                print("Emergency stop")
                LEFT_MOTOR.set_power(0)
                RIGHT_MOTOR.set_power(0)
                reset_brick()
                time.sleep(0.1)
                os._exit(1)
        
        else:
            trigger_time=None
    
    time.sleep(0.01)
    
def turn_pivot(heading):
    current_angle = GYRO_SENSOR.get_abs_measure()
    error = heading - current_angle
    error = (error+180) % 360 - 180
    
    if error > 0:
        LEFT_MOTOR.set_power(power = -35)
        RIGHT_MOTOR.set_power(power = 0)
        
    else:
        LEFT_MOTOR.set_power(power = 0)
        RIGHT_MOTOR.set_power (power = -35)
    time.sleep(0.1)
    
    while True:
        current_angle = GYRO_SENSOR.get_abs_measure()
        error = heading - current_angle
        print(error)
        
        error = (error+180) % 360 - 180
        time.sleep(0.01)
        if abs(error) <= 5:
            LEFT_MOTOR.set_power (0)
            RIGHT_MOTOR.set_power(0)
            break
        
        time.sleep(0.01)
            
        
        
def follow_gyro(heading, reverse = False):
    current_heading = GYRO_SENSOR.get_abs_measure()
    print(current_heading)
    error = heading - current_heading
    error = (error + 180) % 360 -180
    
    turn_rate = error * KP_GYRO
    
    if reverse:
    
        LEFT_MOTOR.set_power (power = clamp_speed((SPEED - turn_rate), 100, 5))
        RIGHT_MOTOR.set_power (power = clamp_speed ((SPEED + turn_rate), 100, 5))
    else:
        LEFT_MOTOR.set_power (power = clamp_speed(-(SPEED + turn_rate), -5, -100))
        RIGHT_MOTOR.set_power (power = clamp_speed (-(SPEED - turn_rate), -5, -100))
        

def dist_gyro(dist, heading):
    target_deg = (dist / WHEEL) * 360

    LEFT_MOTOR.reset_encoder()
    time.sleep(0.01)
    
    while abs(LEFT_MOTOR.get_encoder()) < target_deg:
        follow_gyro(heading)
        time.sleep(0.01)
        
    LEFT_MOTOR.set_power(0)
    RIGHT_MOTOR.set_power(0)
    
def readjust(heading):
    turn(heading + 35)
    time.sleep(0.1)
    drive_distance(10,20)
    time.sleep(0.1)
    turn(heading + 3)
    turn_color_motor(0)
    time.sleep(0.5)

def is_door():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if not rgb_stats:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    orange_dist = math.dist(ORANGE, point)
    if orange_dist < 0.06:
        print("Door detected")
        return True
    else:
        return False
    
def mission_test():
    if not ROUTE:
        return False
    
    current_node = "NODE_0"
    
    for next_node in ROUTE:
        try:
            distance, direction = GRAPH[current_node][next_node]
            print(f"Moving from {current_node} to {next_node} with distance {distance} and direction {direction}")
            COLOR_SENSOR.set_mode("red")
        except KeyError:
            print("Error")
            return False
        
        if abs(direction - GYRO_SENSOR.get_abs_measure()) > 30:
            turn_pivot(direction)
        
        if next_node == "NODE_4":
            turn_color_motor(87)
            time.sleep(0.5)
            
            dist_gyro(5.4, direction)
            time.sleep(0.5)
            
        elif distance <= 15:
            turn_color_motor(0)
            time.sleep(0.1)
            dist_gyro(19, direction)
            time.sleep(0.5)

        elif next_node == "NODE_1":
            turn_color_motor(0)
            time.sleep(0.1)
            follow_line_until(distance)
            time.sleep(0.1)
            
        else:
            turn_color_motor(0)
            follow_line_until(distance)
            time.sleep(0.5)
            dist_gyro(25, direction)
            time.sleep(0.5)
            
        current_node = next_node
        
        if len(RETURN) >= 3:
            RETURN.pop()
            
        RETURN.append(current_node)
        
        if current_node in ROOMS:
            COLOR_SENSOR.set_mode("component")
            heading = ROOMS[current_node]
            
            if current_node == "NODE_4":
                turn_pivot(heading)
                time.sleep(0.1)
                readjust(heading)
                time.sleep(0.1)
            
            elif current_node == "NODE_1":
                turn(heading)
                time.sleep(0.1)
                #while not is_door():
                    #follow_gyro(heading)
                    #time.sleep(0.01)
             
                #dist_gyro(10, heading)
                #time.sleep(0.5)
                
            else:
                turn(heading)
                time.sleep(0.1)
            
            #turn_color_motor(75)
            search_bed(35, heading)
            time.sleep(0.5)
            exit_room(heading)
            
def enter_pharmacy():
    turn_color_motor(85)
    time.sleep(0.5)
    dist_gyro(20, 0)
    time.sleep(0.5)
    turn_pivot(47.5)
    time.sleep(0.1)
    drive_distance(-10.5,20)
    time.sleep(0.1)
    turn_pivot(90)
    drive_distance(10,20)
    time.sleep(0.5)
    
def mission():
    delivery = 0
    current_node = "NODE_0"
    while True:
        #current_node, delivery = mission_test(delivery, current_node)
        
        if delivery == 2 or len(ROUTE) == 0:
            break
        time.sleep(0.01)
        ...
    
            
if __name__ == "__main__":
    try:
        
        wait_ready_sensors(True)
        reset_gyro()
        print(GYRO_SENSOR.get_abs_measure())
        stop()
        COLOR_MOTOR.reset_encoder()
        #COLOR_SENSOR.set_mode('red')
        
        mission_test()
        #enter_pharmacy()
        
        
        
        
    except KeyboardInterrupt:
        pass
    
    finally:
        print("finally")
        print(RETURN)
        RIGHT_MOTOR.set_power(0)
        LEFT_MOTOR.set_power(0)
        PICK_UP_MOTOR.set_power(power=0)
        reset_brick()
    
        
