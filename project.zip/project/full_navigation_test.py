from utils.brick import EV3ColorSensor, Motor, EV3GyroSensor, wait_ready_sensors, EV3ColorSensor, reset_brick, EV3UltrasonicSensor, wait_ready_sensors
import time
import threading
import os
from room_eval2 import exit_room, turn_color_motor
from room_entry_test import follow_line_until

LEFT_MOTOR = Motor('A')
RIGHT_MOTOR = Motor('B')
COLOR_SENSOR = EV3ColorSensor(3)
PICK_UP_MOTOR = Motor ('C')
US_SENSOR = EV3UltrasonicSensor(4)
COLOR_MOTOR = Motor('D')



#OLOR_SENSOR = EV3ColorSensor(1)
GYRO_SENSOR = EV3GyroSensor(2)

WHEEL = 13.5
ORANGE = [0.7113, 0.2328, 0.0559]
BLACK = 15
LINE_TARGET = 52
KP_GYRO = 2
KP = 0.05
KD = 0
KP_TURN = 1.5

SPEED = 30


def clamp_speed (value, min_value, max_value):
    return max(max_value, min(value,min_value))

def follow_line():
    
    COLOR_SENSOR.set_mode('red')
    time.sleep(1)
    
    last_error = 0
    while True:
        
        current_light = COLOR_SENSOR.get_red()
        print(f"Current light: {current_light}")
        
        if current_light is None:
            print("something is wrong")
            continue
        
        
            
        
        error = current_light - LINE_TARGET
            
        derivative = error - last_error
        last_error = error
        time.sleep(0.01)
        turn_rate = error * KP + derivative * KD
            
        LEFT_MOTOR.set_power (power = clamp_speed(-(SPEED -turn_rate), -5, -100))
        RIGHT_MOTOR.set_power (power = clamp_speed(-(SPEED + turn_rate), -5, -100))
            
        print(f"Light: {current_light}, error: {error}, left speed: {clamp_speed(-(SPEED -turn_rate), -20, -100)}, right speed: {clamp_speed(-(SPEED + turn_rate), -20, -100)}") 
            
        time.sleep(0.2)
        
def follow_until(dist):
    target = (dist/WHEEL) * 360
    blind = 0.7*target
    
    LEFT_MOTOR.reset_encoder()
    
    while True:
        current = abs(LEFT_MOTOR.get_encoder())
        current_light = COLOR_SENSOR.get_red()
        
        if current < blind:
            follow_line()
            
        else:
            if current_light <= BLACK:
                print("intersection")
                LEFT_MOTOR.set_power(power = 0)
                RIGHT_MOTOR.set_power (power = 0)
                break
            else:
                follow_line()
        
def drive_distance (dist, speed):
    target_deg = (dist/WHEEL) * 360
    LEFT_MOTOR.set_limits (power = speed)
    RIGHT_MOTOR.set_limits (power = speed)
    
    LEFT_MOTOR.set_position_relative(target_deg)
    RIGHT_MOTOR.set_position_relative(target_deg)
    time.sleep(0.1)
    LEFT_MOTOR.wait_is_stopped()
    RIGHT_MOTOR.wait_is_stopped()
    
def reset_gyro():
    GYRO_SENSOR.set_mode('abs')
    GYRO_SENSOR.wait_ready()
    GYRO_SENSOR.set_mode('both')
    GYRO_SENSOR.wait_ready()
    
def turn (heading):
    
    
    while True:
        current_angle = GYRO_SENSOR.get_abs_measure()
        
        print(f"Turning to {heading}, current angle: {current_angle}")
        
        error = heading - current_angle
        
        error = (error + 180) % 360 -180
        
        if abs(error) <=3:
            LEFT_MOTOR.set_power(power = 0)
            RIGHT_MOTOR.set_power (power =0)
            break
        
        turn_speed = clamp_speed(error*KP_TURN, 70, -70)
        
        if 0 < abs(turn_speed) < 20:
            if turn_speed > 0:
                turn_speed = 15
            else:
                turn_speed = -15
                
        
        
        LEFT_MOTOR.set_power(power = -turn_speed)
        RIGHT_MOTOR.set_power(power = turn_speed)
            
        time.sleep(0.01)
        
def test_intensity():
    print("Waiting for sensor")
    wait_ready_sensors(True)
    print ("Sensor ready")
    COLOR_SENSOR.set_mode('red')
    
    try:
        for i in range(10):
            input("Press Enter: ")
            value = COLOR_SENSOR.get_red()
            print(value)
            
    except KeyboardInterrupt:
        pass
    finally:
        reset_brick()
        print("done")
        
def stop():
    sthread = threading.Thread(target = stop_trigger)
    sthread.daemon = True
    sthread.start()
    
    
def stop_trigger():
    trigger_time = 0
    while True:
        try:
            value = US_SENSOR.get_value()
        except Exception:
            time.sleep(0.01)
            continue
        print(value)
        if 5.0 < value < 15.0:
            if trigger_time is None:
                trigger_time= time.time()
        
            elif time.time() - trigger_time>= 0.5:
                print("Emergency stop")
                LEFT_MOTOR.set_power(0)
                RIGHT_MOTOR.set_power(0)
                reset_brick()
                time.sleep(0.1)
                os._exit(1)
        
        else:
            trigger_time=None
    
    time.sleep(0.01)
    
def turn_pivot(heading):
    current_angle = GYRO_SENSOR.get_abs_measure()
    error = heading - current_angle
    error = (error+180) % 360 - 180
    
    if error > 0:
        LEFT_MOTOR.set_power(power = -45)
        RIGHT_MOTOR.set_power(power = 0)
        
    else:
        LEFT_MOTOR.set_power(power = 0)
        RIGHT_MOTOR.set_power (power = -45)
    time.sleep(0.1)
    
    while True:
        current_angle = GYRO_SENSOR.get_abs_measure()
        error = heading - current_angle
        print(error)
        
        error = (error+180) % 360 - 180
        time.sleep(0.01)
        if abs(error) <= 3:
            LEFT_MOTOR.set_power (0)
            RIGHT_MOTOR.set_power(0)
            break
        
        time.sleep(0.01)
            
        
        
def follow_gyro(heading, reverse = False):
    current_heading = GYRO_SENSOR.get_abs_measure()
    print(current_heading)
    error = heading - current_heading
    error = (error + 180) % 360 -180
    
    turn_rate = error * KP_GYRO
    
    if reverse:
    
        LEFT_MOTOR.set_power (power = clamp_speed((SPEED - turn_rate), 100, 5))
        RIGHT_MOTOR.set_power (power = clamp_speed ((SPEED + turn_rate), 100, 5))
    else:
        LEFT_MOTOR.set_power (power = clamp_speed(-(SPEED + turn_rate), -5, -100))
        RIGHT_MOTOR.set_power (power = clamp_speed (-(SPEED - turn_rate), -5, -100))
        

def dist_gyro(dist, heading, reverse = False):
    target_deg = (dist / WHEEL) * 360
    time.sleep(0.01)
    while abs(LEFT_MOTOR.get_encoder()) < target_deg:
        follow_gyro(heading)
        time.sleep(0.01)
        

    LEFT_MOTOR.set_power(0)
    RIGHT_MOTOR.set_power(0)

    LEFT_MOTOR.reset_encoder()
    
    while abs(LEFT_MOTOR.get_encoder()) < target_deg:
        follow_gyro(heading, reverse = reverse)
        time.sleep(0.01)
        
    LEFT_MOTOR.set_power(0)
    RIGHT_MOTOR.set_power(0)

def is_door():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if not rgb_stats:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    orange_dist = math.dist(ORANGE, point)
    if orange_dist < 0.06:
        print("Door detected")
        return True
    else:
        return False

if __name__ == "__main__":
    try:
        
        wait_ready_sensors(True)
        reset_gyro()
        stop()
        COLOR_MOTOR.reset_encoder()
        
        #Full navigation
    
        #Pharmacy to Room 1
        follow_until(12) # change distance based on distance between current position and target node
        COLOR_SENSOR.set_mode('component')
        time.sleep(1)
        
        LEFT_MOTOR.set_power(power=-15)
        RIGHT_MOTOR.set_power(power=-15)
        
        while not is_door():
           time.sleep(0.01)
        dist_gyro(5, 0)
        
        #Room 1 to Room 2
        turn_color_motor(75)
        time.sleep(0.5)
        exit_room(0)
        time.sleep(0.1)
        drive_distance(-2,20)
        time.sleep(0.1)
        turn_pivot(90)
        time.sleep(0.1)
        turn_color_motor(0)
        COLOR_SENSOR.set.mode('red')
        time.sleep(0.5)
        follow_line_until(12)
        time.sleep(0.5)
        dist_gyro(21,90)
        time.sleep(0.5)
        turn(0)
        dist_gyro(10,0,reverse=True)
        
        #Room 2 to Room 3.1
        turn_color_motor(75)
        time.sleep(0.1)
        drive_distance(-2,20)
        time.sleep(0.1)
        turn_pivot(90)
        time.sleep(0.1)
        turn_color_motor(0)
        COLOR_SENSOR.set_mode('red')
        time.sleep(0.5)
        dist_gyro(18,90)
        time.sleep(0.5)
        turn(179)
        drive_distance(5,20)
        time.sleep(0.1)
        
        #Room 3.1 to Room 3.2
        turn_color_motor(75)
        time.sleep(0.5)
        exit_room(180)
        time.sleep(0.1)
        drive_distance(-2,20)
        time.sleep(0.1)
        turn_pivot(-90)
        time.sleep(0.1)
        turn_color_motor(-85)
        time.sleep(0.5)
        dist_gyro(5.5, 90)
        time.sleep(0.1)
        turn_pivot(0)
        time.sleep(0.1)
        turn(35)
        time.sleep(0.1)
        drive_distance(10,20)
        time.sleep(0.1)
        turn(2)
        turn_color_motor(0)
        time.sleep(0.5)
                
        #Room 3.2 to Pharmacy
        turn_color_motor(75)
        time.sleep(0.5)
        exit_room(180)
        time.sleep(0.1)
        drive_distance(-2,20)
        time.sleep(0.1)
        turn_pivot(87)
        time.sleep(0.1)
        turn_color_motor(0)
        time.sleep(0.1)
        COLOR_SENSOR.set_mode('red')
        time.sleep(0.5)
        follow_line_until(70)
        time.sleep(0.1)
        turn(180)
        time.sleep(0.5)
        COLOR_SENSOR.set_mode('component')
        time.sleep(0.1)
        dist_gyro(7, 0)
        time.sleep(0.5)
        LEFT_MOTOR.set_power(power=-15)
        RIGHT_MOTOR.set_power(power=-15)
        
        while not is_door():
           time.sleep(0.01)
        turn_color_motor(85)
        time.sleep(0.5)
        dist_gyro(18, 0)
        time.sleep(0.5)
        turn_pivot(45)
        time.sleep(0.1)
        drive_distance(-8,20)
        time.sleep(0.1)
        turn_pivot(90)
        drive_distance(10,20)
        
        
        
        
        
    except KeyboardInterrupt:
        pass
    
    finally:
        print("finally")
        RIGHT_MOTOR.set_power(0)
        LEFT_MOTOR.set_power(0)
        PICK_UP_MOTOR.set_power(power=0)
        reset_brick()
    
        
