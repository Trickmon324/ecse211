"""Static test of the gyro sensor. It tests the gyro sensor's ability to measure the zero angle."""


import time
from utils.brick import wait_ready_sensors, reset_brick, EV3GyroSensor

print("Program start.\nWaiting for sensors to turn on...")

wait_ready_sensors(True)
print("Done waiting.")
GYRO_SENSOR = EV3GyroSensor(2)
GYRO_SENSOR_TEST_FILE = "../data_analysis/gyro_static_test.csv"

try:
    with open(GYRO_SENSOR_TEST_FILE, "w") as f:
        
        GYRO_SENSOR.reset_measure()
        
        time.sleep(1)

        for second in range (1,1001):
            angle = GYRO_SENSOR.get_abs_measure()
            f.write(f"{second},{angle}\n")
            print(f"Second: {second}, Angle: {angle}")
            time.sleep(0.01)

except FileNotFoundError:
    print(f"File directory not found")

except KeyboardInterrupt:
    print("Program stopped by user.")

except BaseException as e:
    print(f"An unexpected error occurred: {e}")

finally:
    print("Done")
    exit()
            