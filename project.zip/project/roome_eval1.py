from utils.brick import EV3COlorSensor, Motor, EV3GyroSensor, reset_brick, wait_ready_sensors
import math
import time

PICK_UP_MOTOR = Motor('C')
LEFT_MOTOR = Motor('B')
RIGHT_MOTOR = Motor('A')
WHEEL_CIRCUMFERENCE = math.pi * 4.2
KP_TURN = 3
COLOR_MOTOR = Motor('C')
COLOR_SENSOR = EV3ColorSensor(1)

RED = [0.8237, 0.1022, 0.0741]
GREEN = [0.3868, 0.5234, 0.0899]
ORANGE = [0.7113, 0.2328, 0.0559]

def drive_distance (dist, speed):
    target_deg = (dist / WHEEL_CIRCUMFERENCE) * 360
    
    LEFT_MOTOR.set_limits (power = speed)
    RIGHT_MOTOR.set_limits (power = speed)
    LEFT_MOTOR.set_position_relative(target_deg)
    RIGHT_MOTOR.set_position_relative(target_deg)
    time.sleep(0.01)
    
    LEFT_MOTOR.wait_is_stopped()
    RIGHT_MOTOR.wait_is_stopped()
    
def get_red_or_green():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if rgb_stats[0] is None:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    red_dist = math.dist(RED, point)
    green_dist = math.dist(GREEN, point)
    if red_dist < green_dist and red_dist < 0.06:
        print("Red bed")
        return "RED"
    elif green_dist < red_dist and green_dist < 0.06:
        print("Green bed")
        return "GREEN"
    else:
        return None
    
def turn_color_motor (angle):
    COLOR_MOTOR.set_limits(power = 45)
    COLOR_MOTOR.set_position (angle)
    
def bed_sweep(heading):
    turn_color_motor(heading)
    current_heading = COLOR_MOTOR.get_encoder()
    
    while abs(heading - current_heading) >2:
        color = get_red_or_green()
        if color in ["RED", "GREEN"] and get_red_or_green() == color:
            turn_color_motor(current_heading)
            return color, current_heading
        
        current_heading = COLOR_MOTOR.get_encoder()
        
        time.sleep(0.01)
        
    return None, None

def search_bed():
    turn_color_motor (30)
    current_target = -30
    
    for i in range(5):
        bed_color, current_heading = bed_sweep(current_target)
        if bed_color is not None:
            print(f"{bed_color} bed detected at heading {current_heading}")
            break
        
        drive_distance(4,15)
        
        current_target = current_target * -1
        time.sleep(0.01)
        
def delivery_decision(heading):
    ...
    

if __name__ == "__main__":
    ...
