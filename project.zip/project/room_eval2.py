from utils.brick import EV3ColorSensor, Motor, EV3GyroSensor, reset_brick, wait_ready_sensors
import math
import time
from utils import sound
from room_entry_test import follow_line_until

PICK_UP_MOTOR = Motor('C')
LEFT_MOTOR = Motor('A')
RIGHT_MOTOR = Motor('B')
WHEEL_CIRCUMFERENCE = math.pi * 4.2
KP_TURN = 3
COLOR_MOTOR = Motor('D')
COLOR_SENSOR = EV3ColorSensor (3)
GYRO_SENSOR = EV3GyroSensor(2)


RED = [0.8237, 0.1022, 0.0741]
GREEN = [0.3868, 0.5234, 0.0899]
ORANGE = [0.7113, 0.2328, 0.0559]
YELLOW = [0.560, 0.374, 0.067]
KP_GYRO = 1
GOOD_SOUND = sound.Sound(duration=0.5, pitch="C5", volume=100)
SPEED = 25

def clamp_speed (value, min_speed, max_speed):
    return max(max_speed, min(value,min_speed))

def get_red_or_green():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if rgb_stats[0] is None:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    red_dist = math.dist(RED, point)
    green_dist = math.dist(GREEN, point)
    if red_dist < green_dist and red_dist < 0.06:
        print("Red bed")
        return "RED"
    elif green_dist < red_dist and green_dist < 0.06:
        print("Green bed")
        return "GREEN"
    else:
        return None

def follow_gyro(heading, reverse = False):
    current_heading = GYRO_SENSOR.get_abs_measure()
    print(current_heading)
    error = heading - current_heading
    error = (error + 180) % 360 -180
    
    turn_rate = error * KP_GYRO
    
    if reverse:
    
        LEFT_MOTOR.set_power (power = clamp_speed((SPEED - turn_rate), 100, 5))
        RIGHT_MOTOR.set_power (power = clamp_speed ((SPEED + turn_rate), 100, 5))
    else:
        LEFT_MOTOR.set_power (power = clamp_speed(-(SPEED + turn_rate), -5, -100))
        RIGHT_MOTOR.set_power (power = clamp_speed (-(SPEED - turn_rate), -5, -100))

def drive_distance (dist, speed):
    target_deg = (dist / WHEEL_CIRCUMFERENCE) * 360
    
    LEFT_MOTOR.set_limits (power = speed)
    RIGHT_MOTOR.set_limits (power = speed)
    LEFT_MOTOR.set_position_relative(target_deg)
    RIGHT_MOTOR.set_position_relative(target_deg)
    time.sleep(0.01)
    
    LEFT_MOTOR.wait_is_stopped()
    RIGHT_MOTOR.wait_is_stopped()
    
def get_red_or_green():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if rgb_stats[0] is None:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    red_dist = math.dist(RED, point)
    green_dist = math.dist(GREEN, point)
    if red_dist < green_dist and red_dist < 0.06:
        print("Red bed")
        return "RED"
    elif green_dist < red_dist and green_dist < 0.06:
        print("Green bed")
        return "GREEN"
    else:
        return None
    
def turn_color_motor (angle):
    print("sweeping color sensor")
    COLOR_MOTOR.set_limits(power = 30)
    COLOR_MOTOR.set_position (angle)
    
    
def hard_reset_gyro():
    GYRO_SENSOR.set_mode('abs')
    GYRO_SENSOR.wait_ready()
    GYRO_SENSOR.set_mode('both')
    GYRO_SENSOR.wait_ready()
    time.sleep(0.25)
    
def search_bed(max_dist, heading):
    
    LEFT_MOTOR.set_power(0)
    RIGHT_MOTOR.set_power(0)
    COLOR_SENSOR.set_mode('component')
    time.sleep(0.5)
    if not is_room():
        while not is_door():
            follow_gyro(heading)
            time.sleep(0.01)
            
    else:
        drive_distance(10,20)
        time.sleep(0.5)
    
    current_target = 75
    turn_color_motor(current_target)
    time.sleep(0.01)
    
    LEFT_MOTOR.reset_encoder()
    target_deg = (max_dist/WHEEL_CIRCUMFERENCE) * 360
    
    while abs(LEFT_MOTOR.get_encoder()) < target_deg:
        
        follow_gyro(heading)
        motor_pos = COLOR_MOTOR.get_encoder()
        print(COLOR_MOTOR.get_encoder())
        if abs(current_target - motor_pos) <= 5:
            current_target *= -1
            turn_color_motor(current_target)
            
        color = get_red_or_green()
        
        if color == "GREEN":
            LEFT_MOTOR.set_power(0)
            RIGHT_MOTOR.set_power(0)
            time.sleep(0.01)
            delivery(heading, motor_pos)
            return color, motor_pos
        
        elif color == "RED":
            LEFT_MOTOR.set_power(0)
            RIGHT_MOTOR.set_power(0)
            print("red bed")
            turn_color_motor(75)
            return color, motor_pos
        
        time.sleep(0.01)
    
    turn_color_motor(75)
    LEFT_MOTOR.set_power(0)
    RIGHT_MOTOR.set_power(0)
    return None, None

def delivery(heading, bed_heading):
    print("delivering package")
    
    if abs(bed_heading) < 8:
        turn_color_motor(75)
        drive_distance(-15,20)
        time.sleep(0.5)
        drop()
        #play_good_sound()
        #time.sleep(0.5)
        drive_distance(25,20)
        time.sleep(0.5)
        
    elif abs(bed_heading) < 45:
        if bed_heading < 0:
            turn_color_motor(75)
            time.sleep(0.3)
            turn(heading + 7)
            time.sleep(0.5)
        else:
            turn_color_motor(-75)
            time.sleep(0.5)
            turn(heading -7)
            time.sleep(0.5)
        
        print("forward")
        drive_distance(-15, 30)
        time.sleep(1)
        drop()
        time.sleep(0.01)
        #play_good_sound()
        time.sleep(0.5)
        print("backwards")
        drive_distance(20, 30)
        time.sleep(0.5)
        turn(heading)
        time.sleep(0.1)
        drive_distance(10, 25)
        
    else:
        if bed_heading < 0:
            turn_color_motor(75)
            time.sleep(0.5)
            turn(heading +10)
            time.sleep(0.5)
            
        else:
            turn_color_motor(-75)
            time.sleep(0.5)
            turn(heading-10)
            time.sleep(0.5)
            
        print("forwarda")
        drive_distance(-14, 30)
        time.sleep(1)
        drop()

        time.sleep(0.5)
        print("backwards")
        drive_distance(18, 30)
        time.sleep(0.5)
        turn(heading)

def play_good_sound():
    GOOD_SOUND.play()
    
def turn (heading):
    
    while True:
        current_angle = GYRO_SENSOR.get_abs_measure()
        
        print(f"Turning to {heading}, current angle: {current_angle}")
        
        error = heading - current_angle
        
        error = (error + 180) % 360 -180
        
        if abs(error) <=1:
            LEFT_MOTOR.set_power(power = 0)
            RIGHT_MOTOR.set_power (power =0)
            break
        
        turn_speed = clamp_speed(error*KP_TURN, 70, -70)
        
        if 0 < abs(turn_speed) < 20:
            if turn_speed > 0:
                turn_speed = 15
            else:
                turn_speed = -15
                
        
        
        LEFT_MOTOR.set_power(power = -turn_speed)
        RIGHT_MOTOR.set_power(power = turn_speed)
            
        time.sleep(0.01)


def drop ():
    PICK_UP_MOTOR.set_limits(power = 60)
    PICK_UP_MOTOR.set_position_relative(180)
    time.sleep(0.01)
    PICK_UP_MOTOR.wait_is_stopped()
    
def exit_room(heading):
    COLOR_SENSOR.set_mode('component')
    time.sleep(0.5)
    while not is_door():
        follow_gyro(heading, reverse = True)
        time.sleep(0.01)
    
    drive_distance(-2,20)
    time.sleep(0.5)
    LEFT_MOTOR.set_power(0)
    RIGHT_MOTOR.set_power(0)

def is_door():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if not rgb_stats:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    orange_dist = math.dist(ORANGE, point)
    if orange_dist < 0.06:
        print("Door detected")
        return True
    else:
        return False
    
def is_room():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if not rgb_stats:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    yellow_dist = math.dist(YELLOW, point)
    if yellow_dist < 0.06:
        print("Room detected")
        return True
    else:
        return False

if __name__ == "__main__":
    try:
    
        wait_ready_sensors(True)
        hard_reset_gyro()
        COLOR_SENSOR.set_mode('component')
        time.sleep(0.5)
        COLOR_MOTOR.reset_encoder()
        search_bed(32, 0)
        
    except KeyboardInterrupt:
        pass
    finally:
        LEFT_MOTOR.set_power(0)
        RIGHT_MOTOR.set_power(0)
        reset_brick()
    
    

