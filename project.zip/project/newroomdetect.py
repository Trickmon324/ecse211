from utils.brick import EV3ColorSensor, reset_brick, Motor, EV3GyroSensor, EV3UltrasonicSensor, wait_ready_sensors
from utils import sound
import time
import math
import threading
import os

LEFT_MOTOR = Motor('B')
RIGHT_MOTOR = Motor('A')
COLOR_SENSOR = EV3ColorSensor(3)
GYRO_SENSOR = EV3GyroSensor(2)
US_SENSOR = EV3UltrasonicSensor(1)


WHEEL_CIRCUMFERENCE = 13.5
MAX_SPEED = -100
MIN_SPEED = -5
BLACK_THRESHOLD = 15
LINE_TARGET = 52
KP = 0.05
KD = 0
KP_GYRO = 0.5
SPEED = 20

# Reference RGB vectors (normalized)
RED = [0.8237, 0.1022, 0.0741]
GREEN = [0.3868, 0.5234, 0.0899]
ORANGE = [0.7113, 0.2328, 0.0559]
GOOD_SOUND = sound.Sound(duration=0.5, pitch="C5", volume=100)


def follow_gyro(heading):
    current_heading = GYRO_SENSOR.get_abs_measure()
    print(current_heading)
    error = heading - current_heading
    error = (error + 180) % 360 -180
    
    turn_rate = error * KP_GYRO
    
    LEFT_MOTOR.set_power (power = clamp_speed(-(SPEED + turn_rate), -5, -100))
    RIGHT_MOTOR.set_power (power = clamp_speed (-(SPEED - turn_rate), -5, -100))
    

def get_red_or_green():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if rgb_stats[0] is None:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    red_dist = math.dist(RED, point)
    green_dist = math.dist(GREEN, point)
    if red_dist < green_dist and red_dist < 0.06:
        print("Red bed")
        return "RED"
    elif green_dist < red_dist and green_dist < 0.06:
        print("Green bed")
        return "GREEN"
    else:
        return None
    
def get_orange():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if not rgb_stats:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    orange_dist = math.dist(ORANGE, point)
    if orange_dist < 0.06:
        print("Orange door")
        return "ORANGE"
    else:
        return None
    
def is_door():
    door = get_orange()
    if door == "ORANGE":
        return True
    else:
        return False
    
def play_good_sound():
    GOOD_SOUND.play()
    
def bed_evaluation():
    while True:
        bed = get_red_or_green()
        if bed is not None:
            LEFT_MOTOR.set_position(LEFT_MOTOR.get_encoder())
            RIGHT_MOTOR.set_position(RIGHT_MOTOR.get_encoder())
            return bed
        
def emergency_stop():
    stop_thread = threading.Thread(target = stop_trigger)
    stop_thread.daemon = True
    stop_thread.start()

def stop_trigger():
    trigger_time = None
    while True:
        dist = US_SENSOR.get_value()
        if dist is not None:
            if 5.0 < dist < 15.0:
                if trigger_time is None:
                    trigger_time = time.time()
                elif time.time() - trigger_time >= 0.5:
                    print("Emergency stop triggered")
                    LEFT_MOTOR.set_power(power = 0)
                    RIGHT_MOTOR.set_power(power = 0)
                    os._exit(1)
        
            else:
                trigger_time=None
        time.sleep(0.1)
        
def is_door():
    rgb_stats = COLOR_SENSOR.get_rgb()
    if not rgb_stats:
        return None
    r, g, b = rgb_stats
    denominator = r + g + b + 0.0001
    point = [r / denominator, g / denominator, b / denominator]
    orange_dist = math.dist(ORANGE, point)
    if orange_dist < 0.06:
        print("Door detected")
        return True
    else:
        return False

def clamp_speed (value, min_speed, max_speed):
    return max(max_speed, min(value,min_speed))

def hard_reset_gyro():
    GYRO_SENSOR.set_mode('abs')
    GYRO_SENSOR.wait_ready()
    GYRO_SENSOR.set_mode('both')
    GYRO_SENSOR.wait_ready()
    time.sleep(0.25)

def follow_line(current_light):
    error = current_light - LINE_TARGET
    last_error = 0
    derivative = error - last_error
    last_error = error
    turn_rate = error * KP + derivative * KD
    time.sleep(0.01)
    LEFT_MOTOR.set_power (power = clamp_speed(-(SPEED - turn_rate), MIN_SPEED, MAX_SPEED))
    RIGHT_MOTOR.set_power (power = clamp_speed(-(SPEED + turn_rate), MIN_SPEED, MAX_SPEED))

def drive_distance (dist, speed):
    target_deg = (dist / WHEEL_CIRCUMFERENCE) * 360
    
    LEFT_MOTOR.set_limits (power = speed)
    RIGHT_MOTOR.set_limits (power = speed)
    LEFT_MOTOR.set_position_relative(target_deg)
    RIGHT_MOTOR.set_position_relative(target_deg)
    time.sleep(0.1)
    
    LEFT_MOTOR.wait_is_stopped()
    RIGHT_MOTOR.wait_is_stopped()
        
def follow_line_until(distance):
    
    target_deg = (distance / WHEEL_CIRCUMFERENCE) * 360
    blind_deg = target_deg * 0.6
    LEFT_MOTOR.reset_encoder()
    last_error = 0
    while True:
        current_deg = abs(LEFT_MOTOR.get_encoder())
        current_light = COLOR_SENSOR.get_red()
        if current_deg < blind_deg:
            last_error = follow_line(current_light)
        else:
            if current_light <= BLACK_THRESHOLD:
                print("Intersection detected")
                LEFT_MOTOR.set_power(power = 0)
                RIGHT_MOTOR.set_power (power = 0)
                break
            else:
                last_error = follow_line(current_light)
        time.sleep(0.2)
    

if __name__ == "__main__":
    try:
        wait_ready_sensors(True)
        COLOR_SENSOR.set_mode('red')
        hard_reset_gyro()
    
        follow_line_until(12) # change distance based on distance between current position and target node
        COLOR_SENSOR.set_mode('component')
        time.sleep(1)
        
        LEFT_MOTOR.set_power(power=-15)
        RIGHT_MOTOR.set_power(power=-15)
        
        while not is_door():
            follow_gyro(0)
            time.sleep(0.01)
        
        while True:
            color = bed_evaluation()
            if color == "GREEN":
            
                print("green bed")
                play_good_sound()
                break
            elif color == "RED":
            
                print("red bed")
            
                drive_distance(5, 15)
                print("searching for door")
            
                RIGHT_MOTOR.set_power(power=15)
                LEFT_MOTOR.set_power(power=15)
            
                while not is_door():
                    time.sleep(0.01)
                RIGHT_MOTOR.set_power(power=0)
                RIGHT_MOTOR.set_power(power=0)
            else:
                follow_gyro(0)
            time.sleep(0.01)
        
    except KeyboardInterrupt:
        print("Program interrupted")
    
    finally:
        RIGHT_MOTOR.set_power(0)
        LEFT_MOTOR.set_power(0)
        reset_brick()
    
         
         
