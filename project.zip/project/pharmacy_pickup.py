from utils.brick import Motor, EV3ColorSensor, EV3GyroSensor, EV3UltrasonicSensor, wait_ready_sensors, reset_brick
import time
import math

PICK_UP_MOTOR = Motor('C')
LEFT_MOTOR = Motor('A')
RIGHT_MOTOR = Motor('B')
WHEEL_CIRCUMFERENCE = math.pi * 4.2
KP_TURN = 3
COLOR_MOTOR = Motor('D')
GYRO_SENSOR = EV3GyroSensor('2')

def clamp_speed (value, min_value, max_value):
    return max(max_value, min(value,min_value))

def pick_up ():
    PICK_UP_MOTOR.set_limits(power = 60)
    PICK_UP_MOTOR.set_position_relative(-200)
    time.sleep(0.01)
    PICK_UP_MOTOR.wait_is_stopped()
    

def drive_distance (dist, speed):

    target_deg = (dist / WHEEL_CIRCUMFERENCE) * 360
    
    LEFT_MOTOR.set_limits (power = speed)
    RIGHT_MOTOR.set_limits (power = speed)
    LEFT_MOTOR.set_position_relative(target_deg)
    RIGHT_MOTOR.set_position_relative(target_deg)
    time.sleep(0.1)
    
    LEFT_MOTOR.wait_is_stopped()
    RIGHT_MOTOR.wait_is_stopped()
    
def reset_gyro():
    GYRO_SENSOR.set_mode('abs')
    GYRO_SENSOR.wait_ready()
    GYRO_SENSOR.set_mode('both')
    GYRO_SENSOR.wait_ready()
    
def turn (heading):
    
    
    
    while True:
        current_angle = GYRO_SENSOR.get_abs_measure()
        
        print(f"Turning to {heading}, current angle: {current_angle}")
        
        error = heading - current_angle
        
        error = (error + 180) % 360 -180
        
        if abs(error) <=1:
            LEFT_MOTOR.set_power(power = 0)
            RIGHT_MOTOR.set_power (power =0)
            break
        
        turn_speed = clamp_speed(error * KP_TURN, 70, -70)
        
        if 0 < abs(turn_speed) < 10:
            if turn_speed > 0:
                turn_speed = 10
            else:
                turn_speed = -10
        
        LEFT_MOTOR.set_power(power = - turn_speed)
        RIGHT_MOTOR.set_power(power = turn_speed)
            
        time.sleep(0.01)

def turn_color_motor (angle):
    print("sweeping color sensor")
    COLOR_MOTOR.set_limits(power = 30)
    COLOR_MOTOR.set_position (angle)
    
        
def set_up():
    wait_ready_sensors(True)
    reset_gyro()
    COLOR_MOTOR.reset_encoder()
    turn_color_motor(-20)
    time.sleep(0.5)
    print("forward: 22cm")
    drive_distance(-26, 50)
    time.sleep(1)
    pick_up()
    time.sleep(1)
    print("Backwards: 5cm")
    drive_distance(5,40)
    turn(-20)
    time.sleep(1)
    print("Forward: 10cm")
    drive_distance(-7, 50)
    time.sleep(1)
    pick_up()
    time.sleep(1)
    
    print("Back to original spot")
    
    drive_distance(7, 50)
    print("turning back")
    turn(-2)
    time.sleep(1)
    drive_distance(18, 50)
    time.sleep(1)
    
    turn(-83)
    time.sleep(1)
    
    print("Done")
    LEFT_MOTOR.set_power(power = 0)
    RIGHT_MOTOR.set_power(power = 0)
    
if __name__ == "__main__":
    try:
        set_up()
    except KeyboardInterrupt:
        pass
    finally:
        LEFT_MOTOR.set_power(0)
        RIGHT_MOTOR.set_power(0)
        PICK_UP_MOTOR.set_power(0)
        reset_brick()
    

    

    
