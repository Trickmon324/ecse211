from utils.brick import Motor
import time
other_motor = Motor("A")


motor = Motor("B")


### Power ###
motor.set_power(0) # 100%
time.sleep(2) # Wait to finish



# Prevents position control from going over either:
# 50% power or 90 deg/sec, whichever is slower
other_motor.set_power(0)
time.sleep(2)

